//
//  Constant.m
//  OZNeed
//
//  Created by   on 26/02/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

#import "Constant.h"
#import "CommonHeaders.h"
@implementation Constant

NSString* const URL_LOGIN           =BASE_URL @"user_login_api.php";
NSString* const URL_REGISTER        = BASE_URL @"user_api.php";

+ (UIColor *)defaultBorderColor {
    return [UIColor lightGrayColor];
}

+ (UIColor *)defaultRedColor {
    return [UIColor colorWithHexString:@"c24f5b"];
}



+ (void)setBackgroundGradient:(UIView *)mainView color1Red:(float)colorR1 color1Green:(float)colorG1 color1Blue:(float)colorB1 color2Red:(float)colorR2 color2Green:(float)colorG2 color2Blue:(float)colorB2 alpha:(float)alpha
{
    
    [mainView setBackgroundColor:[UIColor clearColor]];
    CAGradientLayer *grad = [CAGradientLayer layer];
    grad.frame = mainView.bounds;
    
    grad.colors = [NSArray arrayWithObjects:(id)[[UIColor colorWithRed:colorR1/255.0 green:colorG1/255.0 blue:colorB1/255.0 alpha:alpha] CGColor], (id)[[UIColor colorWithRed:colorR2/255.0 green:colorG2/255.0 blue:colorB2/255.0 alpha:alpha] CGColor], nil];
    
    [mainView.layer insertSublayer:grad atIndex:0];
}

@end
