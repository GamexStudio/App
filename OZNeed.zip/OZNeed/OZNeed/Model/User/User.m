
#import "User.h"
#import "NSUserDefaults+Convenience.h"




NSString *const kDataFullName = @"full_name";
NSString *const kDataEmail = @"email";
NSString *const kUserId = @"UserID";
NSString *const kphone = @"phone";
NSString *const kDataAddress = @"address";



//NSString *const kDatagender = @"gender";
//NSString *const kDataAge = @"age";
//NSString *const kDataCountryId = @"country_id";
//NSString *const kDataStateId = @"state_id";
//NSString *const kDataStreetId = @"street_id";
//NSString *const kDataSuburbId = @"suburb_id";
//NSString *const kDataAddressStatus = @"address_status";
//NSString *const kDataLatitude = @"latitude";
//NSString *const kDataLongitude= @"longitude";
//NSString *const kDataNewsletterOnOff = @"newsletter_onoff";
//NSString *const kDataPushnotification = @"push_notification";
//NSString *const KDataCountryName = @"country_name";
//NSString *const KDataStateName = @"state_name";
//NSString *const KDataSuburbName = @"suburb_name";
//NSString *const KDataStreetName = @"street_name";
//
//NSString *const kDataProfilePhoto = @"profile_photo";
//NSString *const kDataProfilePhotoThumb = @"profile_photo_thumb";
//NSString *const kDataBillImage = @"bill_image";
//NSString *const kDataBillImageThumb = @"bill_image_thumb";
//NSString *const kDataBillImageName = @"bill_image_name";
//NSString *const kDataNeighbourHoodStatus = @"neighbourhood_status";
//
//NSString *const KDataUsernameLastUpdatedTimestamps = @"username_last_updated_timestamp";
//NSString *const kDataCurrentTimestamps = @"current_timestamp";
//NSString *const kDatabirthdayUpdateCount = @"birthdate_updated_count";
//NSString *const kDataFacebookId = @"facebook_id";

@interface User ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation User

@synthesize email = _email;
@synthesize fullName = _fullName;
@synthesize userID = _userID;
@synthesize phone = _phone;
@synthesize address = _address;


//@synthesize age = _age;
//@synthesize gender = _gender;
//@synthesize country_id = _country_id;
//@synthesize state_id = _state_id;
//@synthesize street_id = _street_id;
//@synthesize suburb_id = _suburb_id;
//
//@synthesize addressStatus = _addressStatus;
//@synthesize latitude = _latitude;
//@synthesize longitude= _longitude;
//
//@synthesize push_notification = _push_notification;
//@synthesize newsletter_onoff =_newsletter_onoff ;
//
//@synthesize country_name = _country_name;
//@synthesize state_name = _state_name;
//@synthesize suburb_name = _suburb_name;
//@synthesize street_name = _street_name;
//@synthesize profilePhoto = _profilePhoto;
//@synthesize profilePhotoThumb = _profilePhotoThumb;
//@synthesize billImage = _billImage;
//@synthesize billImageThumb = _billImageThumb;
//@synthesize billImageName = _billImageName;
//@synthesize neighbourHoodStatus = _neighbourHoodStatus;
//@synthesize usernameLastUpdatedTimestamp = _usernameLastUpdatedTimestamp;
//@synthesize currentTimestamp = _currentTimestamp;
//@synthesize birthdateUpdatedCount = _birthdateUpdatedCount;
//@synthesize facebookId =_facebookId;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict {
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if (self && [dict isKindOfClass:[NSDictionary class]]) {
            self.email = [self objectOrNilForKey:kDataEmail fromDictionary:dict];
            self.userID = [self objectOrNilForKey:kUserId fromDictionary:dict];
            self.fullName = [self objectOrNilForKey:kDataFullName fromDictionary:dict];
        self.phone = [self objectOrNilForKey:kphone fromDictionary:dict];
        self.address = [self objectOrNilForKey:kDataAddress fromDictionary:dict];

//            self.age = [self objectOrNilForKey:kDataAge fromDictionary:dict];
//        self.gender = [self objectOrNilForKey:kDatagender fromDictionary:dict];
//        self.country_id = [self objectOrNilForKey:kDataCountryId fromDictionary:dict];
//        self.state_id = [self objectOrNilForKey:kDataStateId fromDictionary:dict];
//        self.street_id = [self objectOrNilForKey:kDataStreetId fromDictionary:dict];
//        self.suburb_id = [self objectOrNilForKey:kDataSuburbId fromDictionary:dict];
//        self.addressStatus = [[self objectOrNilForKey:kDataAddressStatus fromDictionary:dict] boolValue];
//        self.latitude = [self objectOrNilForKey:kDataLatitude fromDictionary:dict];
//        self.longitude = [self objectOrNilForKey:kDataLongitude fromDictionary:dict];
//        self.push_notification = [[self objectOrNilForKey:kDataPushnotification fromDictionary:dict] boolValue];
//        self.newsletter_onoff = [[self objectOrNilForKey:kDataNewsletterOnOff fromDictionary:dict] boolValue];
//
//        self.country_name = [self objectOrNilForKey:KDataCountryName fromDictionary:dict];
//        self.state_name = [self objectOrNilForKey:KDataStateName fromDictionary:dict];
//        self.suburb_name = [self objectOrNilForKey:KDataSuburbName fromDictionary:dict];
//        self.street_name = [self objectOrNilForKey:KDataStreetName fromDictionary:dict];
//
//        self.profilePhoto = [self objectOrNilForKey:kDataProfilePhoto fromDictionary:dict];
//        self.profilePhotoThumb = [self objectOrNilForKey:kDataProfilePhotoThumb fromDictionary:dict];
//        self.billImage = [self objectOrNilForKey:kDataBillImage fromDictionary:dict];
//        self.billImageThumb = [self objectOrNilForKey:kDataBillImageThumb fromDictionary:dict];
//        self.billImageName = [self objectOrNilForKey:kDataBillImageName fromDictionary:dict];
//        self.neighbourHoodStatus = [[self objectOrNilForKey:kDataNeighbourHoodStatus fromDictionary:dict] boolValue];
//
//        self.usernameLastUpdatedTimestamp = [self objectOrNilForKey:KDataUsernameLastUpdatedTimestamps fromDictionary:dict];
//        self.currentTimestamp = [self objectOrNilForKey:kDataCurrentTimestamps fromDictionary:dict];
//        self.birthdateUpdatedCount = [self objectOrNilForKey:kDatabirthdayUpdateCount fromDictionary:dict];
//
//        self.facebookId = [self objectOrNilForKey:kDataFacebookId fromDictionary:dict];
        


    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation {
    
    
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.email forKey:kDataEmail];
    [mutableDict setValue:self.userID forKey:kUserId];
    [mutableDict setValue:self.fullName forKey:kDataFullName];
     [mutableDict setValue:self.phone forKey:kphone];
    [mutableDict setValue:self.address forKey:kDataAddress];
    
//    [mutableDict setValue:self.age forKey:kDataAge];
//    [mutableDict setValue:self.gender forKey:kDatagender];
//       [mutableDict setValue:self.country_id forKey:kDataCountryId];
//    [mutableDict setValue:self.state_id forKey:kDataStateId];
//    [mutableDict setValue:self.street_id forKey:kDataStreetId];
//    [mutableDict setValue:self.suburb_id forKey:kDataSuburbId];
//
//    [mutableDict setValue:[NSNumber numberWithBool:self.addressStatus] forKey:kDataAddressStatus];
//    [mutableDict setValue:self.latitude forKey:kDataLatitude];
//    [mutableDict setValue:self.longitude forKey:kDataLongitude];
//
//    [mutableDict setValue:[NSNumber numberWithBool:self.push_notification] forKey:kDataPushnotification];
//    [mutableDict setValue:[NSNumber numberWithBool:self.newsletter_onoff] forKey:kDataNewsletterOnOff];
//
//    [mutableDict setValue:self.country_name forKey:KDataCountryName];
//    [mutableDict setValue:self.state_name forKey:KDataStateName];
//    [mutableDict setValue:self.suburb_name forKey:KDataSuburbName];
//    [mutableDict setValue:self.street_name forKey:KDataStreetName];
//
//    [mutableDict setValue:self.profilePhoto forKey:kDataProfilePhoto];
//    [mutableDict setValue:self.profilePhotoThumb forKey:kDataProfilePhotoThumb];
//    [mutableDict setValue:self.billImage forKey:kDataBillImage];
//    [mutableDict setValue:self.billImageThumb forKey:kDataBillImageThumb];
//    [mutableDict setValue:self.billImageName forKey:kDataBillImageName];
//    [mutableDict setValue:[NSNumber numberWithBool:self.neighbourHoodStatus] forKey:kDataNeighbourHoodStatus];
//
//    [mutableDict setValue:self.usernameLastUpdatedTimestamp forKey:KDataUsernameLastUpdatedTimestamps];
//    [mutableDict setValue:self.currentTimestamp forKey:kDataCurrentTimestamps];
//    [mutableDict setValue:self.birthdateUpdatedCount forKey:kDatabirthdayUpdateCount];
//    [mutableDict setValue:self.facebookId forKey:kDataFacebookId];
    
    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description  {
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict {
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];

    self.email = [aDecoder decodeObjectForKey:kDataEmail];
    self.userID = [aDecoder decodeObjectForKey:kUserId];
    self.fullName = [aDecoder decodeObjectForKey:kDataFullName];
    self.phone = [aDecoder decodeObjectForKey:kphone];
    self.address = [aDecoder decodeObjectForKey:kDataAddress];

    
//    self.age = [aDecoder decodeObjectForKey:kDataAge];
//    self.gender = [aDecoder decodeObjectForKey:kDatagender];
//    self.country_id = [aDecoder decodeObjectForKey:kDataCountryId];
//    self.state_id = [aDecoder decodeObjectForKey:kDataStateId];
//    self.street_id = [aDecoder decodeObjectForKey:kDataStreetId];
//    self.suburb_id = [aDecoder decodeObjectForKey:kDataSuburbId];
//    self.addressStatus = [aDecoder decodeBoolForKey:kDataAddressStatus];
//    self.latitude = [aDecoder decodeObjectForKey:kDataLatitude];
//    self.longitude = [aDecoder decodeObjectForKey:kDataLongitude];
//    self.push_notification = [aDecoder decodeBoolForKey:kDataPushnotification];
//    self.newsletter_onoff = [aDecoder decodeBoolForKey:kDataNewsletterOnOff];
//    self.country_name = [aDecoder decodeObjectForKey:KDataCountryName];
//    self.state_name = [aDecoder decodeObjectForKey:KDataStateName];
//    self.suburb_name = [aDecoder decodeObjectForKey:KDataSuburbName];
//    self.street_name = [aDecoder decodeObjectForKey:KDataStreetName];
//
//    self.profilePhoto = [aDecoder decodeObjectForKey:kDataProfilePhoto];
//    self.profilePhotoThumb = [aDecoder decodeObjectForKey:kDataProfilePhotoThumb];
//    self.billImage = [aDecoder decodeObjectForKey:kDataBillImage];
//    self.billImageThumb = [aDecoder decodeObjectForKey:kDataBillImageThumb];
//    self.billImageName = [aDecoder decodeObjectForKey:kDataBillImageName];
//    self.neighbourHoodStatus = [aDecoder decodeBoolForKey:kDataNeighbourHoodStatus];
//
//    self.usernameLastUpdatedTimestamp = [aDecoder decodeObjectForKey:KDataUsernameLastUpdatedTimestamps];
//    self.currentTimestamp = [aDecoder decodeObjectForKey:kDataCurrentTimestamps];
//    self.birthdateUpdatedCount = [aDecoder decodeObjectForKey:kDatabirthdayUpdateCount];
//
//    self.facebookId = [aDecoder decodeObjectForKey:kDataFacebookId];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_email forKey:kDataEmail];
    [aCoder encodeObject:_userID forKey:kUserId];
    [aCoder encodeObject:_fullName forKey:kDataFullName];
    [aCoder encodeObject:_phone forKey:kphone];
    [aCoder encodeObject:_address forKey:kDataAddress];
    
//    [aCoder encodeObject:_age forKey:kDataAge];
//    [aCoder encodeObject:_gender forKey:kDatagender];
//    [aCoder encodeObject:_country_id forKey:kDataCountryId];
//    [aCoder encodeObject:_state_id forKey:kDataStateId];
//    [aCoder encodeObject:_street_id forKey:kDataStreetId];
//    [aCoder encodeObject:_suburb_id forKey:kDataSuburbId];
//    [aCoder encodeBool:_addressStatus forKey:kDataAddressStatus];
//    [aCoder encodeObject:_latitude forKey:kDataLatitude];
//    [aCoder encodeObject:_longitude forKey:kDataLongitude];
//
//    [aCoder encodeBool:_push_notification forKey:kDataPushnotification];
//    [aCoder encodeBool:_newsletter_onoff forKey:kDataNewsletterOnOff];
//
//    [aCoder encodeObject:_country_name forKey:KDataCountryName];
//    [aCoder encodeObject:_state_name forKey:KDataStateName];
//    [aCoder encodeObject:_suburb_name forKey:KDataSuburbName];
//    [aCoder encodeObject:_street_name forKey:KDataStreetName];
//
//    [aCoder encodeObject:_profilePhoto forKey:kDataProfilePhoto];
//    [aCoder encodeObject:_profilePhotoThumb forKey:kDataProfilePhotoThumb];
//    [aCoder encodeObject:_billImage forKey:kDataBillImage];
//    [aCoder encodeObject:_billImageThumb forKey:kDataBillImageThumb];
//    [aCoder encodeObject:_billImageName forKey:kDataBillImageName];
//    [aCoder encodeBool:_neighbourHoodStatus forKey:kDataNeighbourHoodStatus];
//
//    [aCoder encodeObject:_usernameLastUpdatedTimestamp forKey:KDataUsernameLastUpdatedTimestamps];
//    [aCoder encodeObject:_currentTimestamp forKey:kDataCurrentTimestamps];
//    [aCoder encodeObject:_birthdateUpdatedCount forKey:kDatabirthdayUpdateCount];
//    [aCoder encodeObject:_facebookId forKey:kDataFacebookId];
    
}

- (id)copyWithZone:(NSZone *)zone {
    User *copy = [[User alloc] init];
    if (copy) {

        copy.email = [self.email copyWithZone:zone];
        copy.userID = self.userID;
        copy.fullName = [self.fullName copyWithZone:zone];
        copy.phone = [self.phone copyWithZone:zone];
        copy.address = [self.address copyWithZone:zone];
        
//        copy.age = [self.age copyWithZone:zone];
//        copy.gender = [self.gender copyWithZone:zone];
//
//        copy.country_id = [self.country_id copyWithZone:zone];
//        copy.state_id = [self.state_id copyWithZone:zone];
//        copy.street_id = [self.street_id copyWithZone:zone];
//        copy.suburb_id = [self.suburb_id copyWithZone:zone];
//        
//        copy.addressStatus = self.addressStatus ;
//        copy.latitude = [self.latitude copyWithZone:zone];
//        copy.longitude = [self.longitude copyWithZone:zone];
//        
//        copy.push_notification = self.push_notification ;
//        copy.newsletter_onoff = self.newsletter_onoff ;
//        
//        copy.country_name = [self.country_name copyWithZone:zone];
//        copy.state_name = [self.state_name copyWithZone:zone];
//        copy.suburb_name = [self.suburb_name copyWithZone:zone];
//        copy.street_name = [self.street_name copyWithZone:zone];
//        copy.profilePhoto = [self.profilePhoto copyWithZone:zone];
//        copy.profilePhotoThumb = [self.profilePhotoThumb copyWithZone:zone];
//        copy.billImage = [self.billImage copyWithZone:zone];
//        copy.billImageThumb = [self.billImageThumb copyWithZone:zone];
//        copy.billImageName = [self.billImageName copyWithZone:zone];
//        copy.neighbourHoodStatus = self.neighbourHoodStatus;
//        
//        copy.usernameLastUpdatedTimestamp = [self.usernameLastUpdatedTimestamp copyWithZone:zone];
//        copy.currentTimestamp = [self.currentTimestamp copyWithZone:zone];
//        copy.birthdateUpdatedCount = [self.birthdateUpdatedCount copyWithZone:zone];
//        copy.facebookId = [self.facebookId copyWithZone:zone];

    }
    
    return copy;
}


+ (User *)loggedInUser {
    return (User *)[NSStandardUserDefaults loadCustomObjectWithKey:kUserId];
}

- (void)save {
    [NSStandardUserDefaults saveCustomObject:self key:kUserId];
    [NSStandardUserDefaults synchronize];
}

- (void)remove {
    [NSStandardUserDefaults removeObjectForKey:kUserId];
    [NSStandardUserDefaults synchronize];
}


@end
