

#import <Foundation/Foundation.h>


@interface User : NSObject <NSCoding, NSCopying>
@property (nonatomic, strong) NSNumber *userID;
@property (nonatomic, strong) NSString *fullName;
@property (nonatomic,strong)  NSString *address;
@property (nonatomic, strong) NSString *email;
@property (nonatomic,strong)  NSString *phone;

//@property (nonatomic, strong) NSString *age;
//@property (nonatomic, strong) NSString *gender;




//@property (nonatomic,strong)  NSNumber *country_id;
//@property (nonatomic,strong)  NSNumber *state_id;
//@property (nonatomic,strong)  NSNumber *street_id;
//@property (nonatomic,strong)  NSNumber *suburb_id;
//@property (nonatomic,assign)  BOOL addressStatus;
//@property (nonatomic,strong)  NSString *latitude;
//@property (nonatomic,strong)  NSString *longitude;


//@property (nonatomic,strong)  NSString *country_name;
//@property (nonatomic,strong)  NSString *state_name;
//@property (nonatomic,strong)  NSString *suburb_name;
//@property (nonatomic,strong)  NSString *street_name;

//@property (nonatomic, assign) BOOL push_notification;
//@property (nonatomic, assign) BOOL newsletter_onoff;

@property (nonatomic,strong) NSString *profilePhoto;
@property (nonatomic,strong) NSString *profilePhotoThumb;
//@property (nonatomic,strong) NSString *billImage;
//@property (nonatomic,strong) NSString *billImageThumb;
//@property (nonatomic,strong) NSString *billImageName;
//@property (nonatomic,assign) BOOL neighbourHoodStatus;

///@property (nonatomic,strong) NSString *usernameLastUpdatedTimestamp;
//@property (nonatomic,strong) NSString *currentTimestamp;
//@property (nonatomic,strong) NSNumber *birthdateUpdatedCount;

//@property (nonatomic,strong) NSString *facebookId;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

+ (User *)loggedInUser;
- (void)save;
- (void)remove;
@end
