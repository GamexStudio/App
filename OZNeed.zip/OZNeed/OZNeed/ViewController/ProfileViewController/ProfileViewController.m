//
//  ProfileViewController.m
//  OZNeed
//
//  Created by   on 11/03/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

#import "ProfileViewController.h"
#import "CommonHeaders.h"

@interface ProfileViewController ()

@end

@implementation ProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setProfile];
    [self addNavigatioinBarview];
    // Do any additional setup after loading the view.
}

-(void)setProfile{
    
    _imgProfile.layer.cornerRadius = _imgProfile.width/2;
    _imgProfile.clipsToBounds = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)addNavigatioinBarview
{
    
    [self.view addSubview:({
        topView = [TopNavBarView getTopNavBarView];
        
        [topView.lblTitle setHidden:YES];
        [topView.userDetails setHidden:YES];
        [topView.lblUserLetterImage setHidden:NO];
        [topView.lblnavTitle setText:@"My Profile"];
        
        
        [topView setLayoutForCenterTitle];
        //[topView setLeftBarButtons:[self leftButtons]];
        //[topView setRightBarButtons:[self rightButtons]];
        topView.view;
    })];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
