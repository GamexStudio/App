//
//  ProfileViewController.h
//  OZNeed
//
//  Created by   on 11/03/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonHeaders.h"
@interface ProfileViewController : UIViewController{
    
    TopNavBarView *topView;
}

@property (weak, nonatomic) IBOutlet UIView *IBContentView;
@property (weak, nonatomic) IBOutlet UIImageView *imgProfile;
@end
