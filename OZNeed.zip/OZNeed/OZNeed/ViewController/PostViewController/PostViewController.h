//
//  PostViewController.h
//  OZNeed
//
//  Created by   on 24/07/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PostViewController : UIViewController

@end
