//
//  DashboardViewController.m
//  Test
//
//  Created by   on 06/02/17.
//  Copyright © 2017 Nishita_MAC. All rights reserved.
//

#import "DashboardViewController.h"
#import "CommonHeaders.h"
@interface DashboardViewController ()<LCBannerViewDelegate>

@property (nonatomic, weak) LCBannerView *bannerView1;
@property (nonatomic) NSMutableArray *arrCategories;
@property (nonatomic) UIEdgeInsets sectionInsets;
@property (nonatomic) NSMutableArray *arrImages;
@property (nonatomic) NSArray *arrUrls;

@end

@implementation DashboardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.sectionInsets = UIEdgeInsetsMake(10.0, 10.0, 10.0, 10.0);
    self.arrCategories = [NSMutableArray arrayWithObjects:@"Plumber", @"Carpenter", @"Party Planner", @"Lawyer", @"Dietician", @"Electrician", @"Fitness Trainer", @"Laundry", @"Wedding Planner", @"Wedding Photoshoot", @"Salon at Home", nil];
    
    self.arrImages = [NSMutableArray arrayWithObjects:@"Plumber",@"carpenter",@"PartyPlanner",@"lawyer",@"dietician",@"Electrician",@"fitnessTrainer",@"laundry",@"Wedding-planner",@"photographer",@"salon", nil];
    self.arrUrls = [[NSArray alloc] initWithObjects:@"https://images.pexels.com/photos/248797/pexels-photo-248797.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", @"https://images.pexels.com/photos/34950/pexels-photo.jpg?auto=compress&cs=tinysrgb&h=350", nil];
    
    
    [self loadBanners];
    [self addNavigatioinBarview];
    [self performSelector:@selector(changed) withObject:nil afterDelay:3.0f];
}

#pragma mark load Banners
-(void)loadBanners
{
//    [_IBView addSubview:({
//
//        LCBannerView *bannerView = [LCBannerView bannerViewWithFrame:CGRectMake(0, 300.0f, [UIScreen mainScreen].bounds.size.width, 200.0f)
//                                                            delegate:self
//                                                           imageURLs:_arrUrls
//                                                placeholderImageName:nil
//                                                        timeInterval:2.0f
//                                       currentPageIndicatorTintColor:[UIColor redColor]
//                                              pageIndicatorTintColor:[UIColor whiteColor]];
//        bannerView.pageDistance = 20.0f;
//        bannerView;
//    })];
    
    
    /******************** local ********************/
   [_IBView addSubview:({
    
    
    
        LCBannerView *bannerView = [[LCBannerView alloc] initWithFrame:CGRectMake(0, 20.0f, [UIScreen mainScreen].bounds.size.width, 200.0f)
                                                              delegate:nil
                                                             imageName:@"banner"
                                                                 count:2
                                                          timeInterval:3.0f
                                         currentPageIndicatorTintColor:[UIColor orangeColor]
                                                pageIndicatorTintColor:[UIColor whiteColor]];
        bannerView.pageDistance = 20.0f;
    
        bannerView.didClickedImageIndexBlock = ^(LCBannerView *bannerView, NSInteger index) {
    
            NSLog(@"Block: Clicked image in %p at index: %d", bannerView, (int)index);
        };
    
        bannerView.didScrollToIndexBlock = ^(LCBannerView *bannerView, NSInteger index) {
    
            NSLog(@"Block: Scrolled in %p to index: %d", bannerView, (int)index);
        };
    
                bannerView.notScrolling = YES;
        self.bannerView1 = bannerView;
    })];
    
}

#pragma mark Topnavigation 
-(void)addNavigatioinBarview
{
    
    [self.view addSubview:({
        topView = [TopNavBarView getTopNavBarView];
        
        [topView.lblTitle setHidden:YES];
        [topView.userDetails setHidden:YES];
        [topView.lblUserLetterImage setHidden:NO];
        [topView.lblnavTitle setText:@"OZNeed"];
        
        
        [topView setLayoutForCenterTitle];
        //[topView setLeftBarButtons:[self leftButtons]];
        //[topView setRightBarButtons:[self rightButtons]];
        topView.view;
    })];
    
}

- (NSMutableArray *) leftButtons {
    NSMutableArray *arrLeftButtons = [[NSMutableArray alloc] init];
    [arrLeftButtons addBarButtonWithTintColor:[UIColor whiteColor] icon:[UIImage imageNamed:@"logo"] target:self selector:nil forControlEvents:UIControlEventTouchUpInside];
    return arrLeftButtons;
}


-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)changed {
    self.bannerView1.count = 3;
}

#pragma mark: - UICollection View Delegate Methods

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return [self.arrCategories count];
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CategoryCell" forIndexPath:indexPath];
    UILabel *categoryName;
    UIImageView *imageView;
    categoryName = (UILabel *)[cell viewWithTag:1];
    imageView = (UIImageView *)[cell viewWithTag:2];
    imageView.image = [UIImage imageNamed:[self.arrImages objectAtIndex:indexPath.row]];
    categoryName.text = [self.arrCategories objectAtIndex:indexPath.row];
    
    cell.contentView.layer.cornerRadius = 10.0f;
    cell.contentView.layer.borderColor = [Constant defaultBorderColor].CGColor;
    cell.contentView.layer.borderWidth = 1.0f;
    return cell;
}

//#pragma mark: - UICollectionView Flow layout Delegate Methods

-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return _sectionInsets;
}

-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return self.sectionInsets.left;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    float paddingSpace = self.sectionInsets.left * 4.0;
    float availableWidth = self.view.frame.size.width - paddingSpace;
    float widthPerItem = availableWidth / 3;
    
    return CGSizeMake(widthPerItem, widthPerItem);
}

@end
