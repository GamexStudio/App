//
//  DashboardDetailsViewController.m
//  Test
//
//  Created by   on 08/02/17.
//  Copyright © 2017 Nishita_MAC. All rights reserved.
//

#import "DashboardDetailsViewController.h"
#import "CommonHeaders.h"
@interface DashboardDetailsViewController (){
    NSMutableArray *arrFreelancerNames;
    NSMutableArray *arrFreelancerDetails;
    NSMutableArray *arrFreelancerImages;
}

@end

@implementation DashboardDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
   // [Constant setBackgroundGradient:self.view color1Red:140.0 color1Green:220.0 color1Blue:240.0 color2Red:129.0 color2Green:178.0 color2Blue:245.0 alpha:1.0];

    [self.IBTblDetails registerNib:[UINib nibWithNibName:@"ListCell" bundle:nil] forCellReuseIdentifier:kListCellIdentifiers];

    [self.IBTblDetails setBackgroundColor:[UIColor clearColor]];
    self.IBTblDetails.tableFooterView = [UIView new];
    
    [self addNavigatioinBarview];
}


#pragma mark Topnavigation
-(void)addNavigatioinBarview
{
    
    [self.view addSubview:({
        topView = [TopNavBarView getTopNavBarView];
        
        [topView.lblTitle setHidden:YES];
        [topView.userDetails setHidden:YES];
        [topView.lblUserLetterImage setHidden:NO];
        [topView.lblnavTitle setText:@"OZNeed"];
        
        
        [topView setLayoutForCenterTitle];
        [topView setLeftBarButtons:[self leftButtons]];
        //[topView setRightBarButtons:[self rightButtons]];
        topView.view;
    })];
    
}

- (NSMutableArray *) leftButtons {
    NSMutableArray *arrLeftButtons = [[NSMutableArray alloc] init];
    [arrLeftButtons addBarButtonWithTintColor:[UIColor whiteColor] icon:[UIImage imageNamed:@"Back"] target:self selector:@selector(btnBackClick) forControlEvents:UIControlEventTouchUpInside];
    return arrLeftButtons;
}

#pragma  mark back Click
-(void)btnBackClick{
    [self.navigationController popViewControllerAnimated:YES];
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark : - UITableView delegate Methods

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ListCell *cell = [tableView dequeueReusableCellWithIdentifier:kListCellIdentifiers forIndexPath:indexPath];
   
    cell.backgroundColor = [UIColor clearColor];
    cell.lblName.text = @"Jhon Phillas";
    cell.lblNumber.text = @"+91 9904081622";
    NSString *stnName = cell.lblName.text;
    [cell.imgProfile setImageWithString:stnName color:[UIColor randomColor] circular:YES fontName:nil];
    
    return cell;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 10;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark: - Button Actions
- (IBAction)backBtnPressed:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}



@end
