//
//  ServiceDetailsViewController.h
//  OZNeed
//
//  Created by   on 24/07/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ServiceDetailsViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tblServiceDetails;
- (IBAction)backBtnClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnBack;
@end
