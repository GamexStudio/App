//
//  DashboardDetailsViewController.h
//  Test
//
//  Created by   on 08/02/17.
//  Copyright © 2017 Nishita_MAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonHeaders.h"
@interface DashboardDetailsViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>{
    TopNavBarView *topView;

}
@property (strong, nonatomic) IBOutlet UITableView *IBTblDetails;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *IBBtnBack;
- (IBAction)backBtnPressed:(id)sender;

@end
