//
//  HomeViewController.m
//  OZNeed
//
//  Created by   on 24/07/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

#import "HomeViewController.h"
#import "HomeCell.h"
#import "DashboardDetailsViewController.h"


@interface HomeViewController ()<LCBannerViewDelegate>{
    NSMutableArray *arrServices;
    NSMutableArray *arrServicesImage;
}

@property (nonatomic, weak) LCBannerView *bannerView1;
@property (nonatomic) NSArray *arrUrls;



@end


@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadBanners];
    [self addNavigatioinBarview];
    [self performSelector:@selector(changed) withObject:nil afterDelay:3.0f];
    
    self.tblServices.delegate   = self;
    self.tblServices.dataSource = self;
    
    self.arrUrls = [[NSArray alloc] initWithObjects:@"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSAPjxjdGlFmYFihOV0I1pmwHzY3P5f1fuFOQyKnfkC-H_3JGJn", @"http://desssign.com/images/Star-Full.png", nil];
    
    arrServices = [[NSMutableArray alloc] initWithObjects:@"Services", @"Buy & Sell", @"Events", @"Food", nil];
    
    arrServicesImage = [[NSMutableArray alloc] initWithObjects:@"services-3", @"buy", @"events", @"food", nil];
    
    self.tblServices.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark load Banners
-(void)loadBanners
{
    
    /******************** local ********************/
    [_viewBannerContainer addSubview:({

        LCBannerView *bannerView = [[LCBannerView alloc] initWithFrame:CGRectMake(0, 20.0f, [UIScreen mainScreen].bounds.size.width, 200.0f)
                                                              delegate:nil
                                                             imageName:@"banner"
                                                                 count:2
                                                          timeInterval:3.0f
                                         currentPageIndicatorTintColor:[UIColor orangeColor]
                                                pageIndicatorTintColor:[UIColor whiteColor]];
        bannerView.pageDistance = 20.0f;
        bannerView.hidePageControl = true;
        bannerView.didClickedImageIndexBlock = ^(LCBannerView *bannerView, NSInteger index) {

            NSLog(@"Block: Clicked image in %p at index: %d", bannerView, (int)index);
        };
        
//        [UIView animateWithDuration:5.0 animations:^(void){
            bannerView.didScrollToIndexBlock = ^(LCBannerView *bannerView, NSInteger index) {
                
                NSLog(@"Block: Scrolled in %p to index: %d", bannerView, (int)index);
            };
//        }];
        
//        bannerView.didScrollToIndexBlock = ^(LCBannerView *bannerView, NSInteger index) {
//
//            NSLog(@"Block: Scrolled in %p to index: %d", bannerView, (int)index);
//        };

        //        bannerView.notScrolling = YES;
        self.bannerView1 = bannerView;
    })];
    
//    [_viewBannerContainer addSubview:({
//
//        LCBannerView *bannerView = [LCBannerView bannerViewWithFrame:CGRectMake(0, 300.0f, [UIScreen mainScreen].bounds.size.width, 200.0f)
//                                                            delegate:self
//                                                           imageURLs:_arrUrls
//                                                placeholderImageName:nil
//                                                        timeInterval:2.0f
//                                       currentPageIndicatorTintColor:[UIColor redColor]
//                                              pageIndicatorTintColor:[UIColor whiteColor]];
//        bannerView.pageDistance = 20.0f;
//        self.bannerView1 = bannerView;
//    })];
}


#pragma mark Topnavigation
-(void)addNavigatioinBarview
{
    
    [self.view addSubview:({
        topView = [TopNavBarView getTopNavBarView];
        
        [topView.lblTitle setHidden:YES];
        [topView.userDetails setHidden:YES];
        [topView.lblUserLetterImage setHidden:NO];
        [topView.lblnavTitle setText:@"OZNeed"];
        
        
        [topView setLayoutForCenterTitle];
        //[topView setLeftBarButtons:[self leftButtons]];
        //[topView setRightBarButtons:[self rightButtons]];
        topView.view;
    })];
    
}

- (NSMutableArray *) leftButtons {
    NSMutableArray *arrLeftButtons = [[NSMutableArray alloc] init];
    [arrLeftButtons addBarButtonWithTintColor:[UIColor whiteColor] icon:[UIImage imageNamed:@"logo"] target:self selector:nil forControlEvents:UIControlEventTouchUpInside];
    return arrLeftButtons;
}

#pragma mark :- TableView Delegate and Datasource Methods

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HomeCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HomeCell" forIndexPath:indexPath];
    
    cell.lblServiceName.text = [arrServices objectAtIndex:indexPath.row];
    cell.imgService.image = [UIImage imageNamed:[arrServicesImage objectAtIndex:indexPath.row]];
    
    return cell;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrServices.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 103.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
  
}

#pragma mark :- Other method
- (void)changed {
    self.bannerView1.count = 3;
}




@end
