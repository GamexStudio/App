//
//  LoginViewController.m
//  Test
//
//  Created by   on 01/02/17.
//  Copyright © 2017 Nishita_MAC. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.viewTintColor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.6];
    
    [self setupViewAppearance];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark btnLogin Click

-(IBAction)btnLoginClick:(id)sender{
    
    
    if ([self isValidateData]) {
        
        
        [SVProgressHUD show];
        NSDictionary *dictParm = @{@"Action":@"UserLogin",@"UserName":_IBTextEmail.text,@"Password":_IBTextPassword.text};
        
        [WebClient requestWithURL:URL_LOGIN parameters:dictParm requestCompletionBlock:^(id responseObject, NSError *error) {
            [SVProgressHUD dismiss];
            
            if (!error) {
                
                User *objUser = [User modelObjectWithDictionary:responseObject[kDataKey]];
                [objUser save];

            }
            else{
            
                [ToastView show:error.localizedDescription];
            }
            
        }];
    }
    
}

-(BOOL)isValidateData
{
    
    if (![_IBTextEmail.text isValid]) {
        
        [ToastView show:@"Please enter Emailid"];
    }
    else if (![_IBTextEmail.text isValidEmail])
    {
        [ToastView show:@"Please enter Valid Emailid"];
    }
    else if (![_IBTextPassword.text isValid])
    {
        [ToastView show:@"Please enter Password"];
    }
    
    else{
    
        return true;
    }
    return false;
}


-(void)setupViewAppearance{
    self.IBBtnLogin.layer.borderWidth = 1.0;
    self.IBBtnLogin.layer.cornerRadius = 10.0;
    self.IBBtnNotaUser.layer.borderWidth = 1.0;
    self.IBBtnNotaUser.layer.cornerRadius = 10.0;
    
    self.IBBtnLogin.layer.borderWidth = 1.0;
    self.IBBtnLogin.layer.cornerRadius = 10.0;
    self.IBBtnNotaUser.backgroundColor = self.viewTintColor;
    self.IBBtnLogin.backgroundColor = self.viewTintColor;
    
}

@end
