//
//  RegistrationViewController.m
//  Test
//
//  Created by   on 02/02/17.
//  Copyright © 2017 Nishita_MAC. All rights reserved.
//

#import "RegistrationViewController.h"
#import "CommonHeaders.h"
@interface RegistrationViewController ()<UITextFieldDelegate>

@end

@implementation RegistrationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.viewTintColor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.6];
    
        
    [self setupViewAppearance];
    // Do any additional setup after loading the view.
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear: YES];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

-(IBAction)btnRegisterClick:(id)sender
{
    
    if ([self isRegisterDataValidate])
    {
        [SVProgressHUD show];
        NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
        [params setValue:@"AddUser" forKey:@"Action"];
        [params setValue:self.IBTxtName.text forKey:@"UserName"];
        [params setValue:_IBTxtEmail.text forKey:@"UserEmail"];
        [params setValue:_IBTxtPassword.text forKey:@"Password"];
        [params setValue:_IBTxtMobileNo.text forKey:@"UserMobile"];
        [params setValue:self.IBTxtAddress.text forKey:@"UserAddress"];
        [params setValue:@"" forKey:@"Photo"];
        [params setValue:_IBTxtMobileNo.text forKey:@"UserPhone"];
        [params setValue:@"Sydney" forKey:@"UserCity"];
        [params setValue:@"Sydney" forKey:@"UserState"];
        [params setValue:@"Aus" forKey:@"UserCountry"];
        [params setValue:@"" forKey:@"UserZip"];
        [params setValue:@"" forKey:@"UserDOB"];
       
        [WebClient requestWithURL:URL_REGISTER parameters:params requestCompletionBlock:^(id responseObject, NSError *error) {
            
            [SVProgressHUD dismiss];
            
            if(!error) {
               
                User *objUser = [User modelObjectWithDictionary:responseObject[kDataKey]];
                [objUser save];
                [ToastView show:kRegistrationMessage];
                
                
          
            }
            else {
                [ToastView show:error.localizedDescription];
            }
            
        }];

        
        
    }
    
}

-(BOOL)isRegisterDataValidate{
    
       if (![_IBTxtName.text isValid]) {
            
            [ToastView show:@"Please enter Full Name"];
        }
    
        
        else{
            
            return true;
        }
    
        return false;
        
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setupViewAppearance{
    self.IBBtnSignUp.layer.borderWidth = 1.0;
    self.IBBtnSignUp.layer.cornerRadius = 10.0;
    self.IBBtnSignUp.backgroundColor = self.viewTintColor;
    self.IBTxtName.delegate = self;
    self.IBTxtEmail.delegate = self;
    self.IBTxtMobileNo.delegate = self;
    self.IBTxtState.delegate = self;
    self.IBTxtPassword.delegate = self;
    self.IBTxtConfirmPassword.delegate = self;
    self.IBTxtAddress.delegate = self;

    //[self.scrollView setContentSize:CGSizeMake(self.scrollView.width, 1000)];
    [self.scrollView autocalculateContentHeight];
}




#pragma mark: - UITextField delegate methods
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    NSInteger nextTag = textField.tag + 1;
    // Try to find next responder
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    if (nextResponder) {
        // Found next responder, so set it.
        [nextResponder becomeFirstResponder];
    } else {
        // Not found, so remove keyboard.
        [textField resignFirstResponder];
    }
    return NO; // We do not want UITextField to insert line-breaks.
}

#pragma mark : - IBActions
- (IBAction)btnBackClick:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}
@end
