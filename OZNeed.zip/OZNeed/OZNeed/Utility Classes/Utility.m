

#import "Utility.h"

static Utility *utility = nil;
@implementation Utility

+ (Utility *)sharedUtility {
    if (!utility) {
        utility = [[Utility alloc] init];
        [[NSNotificationCenter defaultCenter] addObserver:utility selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:utility selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    }
    return utility;
}

+ (void)convertSecondIntoWDHMS:(NSInteger)totalSeconds WithBlock:(void (^)(NSInteger week, NSInteger day, NSInteger hours, NSInteger minutes, NSInteger seconds))completion {

    static const NSInteger SECONDS_PER_MINUTE = 60;
    static const NSInteger MINUTES_PER_HOUR = 60;
    static const NSInteger SECONDS_PER_HOUR = 3600;
    static const NSInteger HOURS_PER_DAY = 24;
    static const NSInteger SECONDS_PER_WEEK = 604800;
    static const NSInteger SECONDS_PER_DAY = 86400;

    NSInteger wholeSeconds = totalSeconds;

    NSInteger aweeks = (wholeSeconds / SECONDS_PER_WEEK);
    NSInteger adays = ((wholeSeconds % SECONDS_PER_WEEK) / SECONDS_PER_DAY);
    NSInteger ahours = (wholeSeconds / SECONDS_PER_HOUR) % HOURS_PER_DAY;
    NSInteger aminutes = (wholeSeconds / SECONDS_PER_MINUTE) % MINUTES_PER_HOUR;
    NSInteger aseconds = wholeSeconds % SECONDS_PER_MINUTE;

    if(completion) {
        completion(aweeks,adays,ahours,aminutes,aseconds);
    }
}

+ (void)convertSecondIntoHMS:(NSTimeInterval)timestamp WithBlock:(void (^)(NSInteger hours, NSInteger minutes, NSInteger seconds))completion {
    static const uint SECONDS_PER_MINUTE = 60;
    static const uint MINUTES_PER_HOUR = 60;
    static const uint SECONDS_PER_HOUR = 3600;
    static const uint HOURS_PER_DAY = 24;

    uint wholeSeconds = (uint)timestamp;

    NSInteger hours = (wholeSeconds / SECONDS_PER_HOUR) % HOURS_PER_DAY;
    NSInteger minutes = (wholeSeconds / SECONDS_PER_MINUTE) % MINUTES_PER_HOUR;
    NSInteger seconds = wholeSeconds % SECONDS_PER_MINUTE;

    if(completion) {
        completion(hours,minutes,seconds);
    }
}

- (NSDate *)dateFromUnixTimeStamp:(NSTimeInterval)unixTime timeZone:(NSTimeZone *)timeZone {
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:unixTime];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:timeZone];
    [dateFormatter setDateFormat:@"dd-MM-yyyy HH:mm:ss"];
    NSString *string = [dateFormatter stringFromDate:date];
    return [dateFormatter dateFromString:string];
}

#pragma mark - UIKeyboard Notification

- (void)keyboardWillShowWithCompletion:(void (^)(CGSize size))completion {
    KeyboardWillShowNotificationBlock = completion;
}

- (void)keyboardWillShow:(NSNotification *)notification {
    if (KeyboardWillShowNotificationBlock) {
        CGSize keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
        KeyboardWillShowNotificationBlock(keyboardSize);
    }
}

- (void)keyboardWillHideWithCompletion:(void (^)(CGSize size))completion {
    KeyboardWillHideNotificationBlock = completion;
}

- (void)keyboardWillHide:(NSNotification *)notification {
    if (KeyboardWillHideNotificationBlock) {
        CGSize keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
        KeyboardWillHideNotificationBlock(keyboardSize);
    }
}

- (NSString *)addressStringFromPlacemark:(CLPlacemark *)placemark {
    NSString *strAddress = @"";
    if(placemark.name) {
        strAddress = [strAddress stringByAppendingString:placemark.name];
    }
    if(placemark.subLocality) {
        strAddress = [strAddress stringByAppendingString:@", "];
        strAddress = [strAddress stringByAppendingString:placemark.subLocality];
    }
    if(placemark.locality) {
        strAddress = [strAddress stringByAppendingString:@", "];
        strAddress = [strAddress stringByAppendingString:placemark.locality];
    }
    if(placemark.ISOcountryCode) {
        strAddress = [strAddress stringByAppendingString:@", "];
        strAddress = [strAddress stringByAppendingString:placemark.ISOcountryCode];
    }
    if(placemark.postalCode) {
        strAddress = [strAddress stringByAppendingString:@", "];
        strAddress = [strAddress stringByAppendingString:placemark.postalCode];
    }
    return strAddress;
}

-(void)dealloc {
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

@end
