#import <UIKit/UIKit.h>

NSString *const kRegularFontName       = @"HelveticaNeue";
NSString *const kBoldFontName          = @"HelveticaNeue-Bold";
NSString *const kLightFontName         = @"HelveticaNeue-Light";
NSString *const kMediumFontName        = @"HelveticaNeue-Medium";

NSString* fontNameFromType(NSString *fontType) {
    
    if ([[fontType lowercaseString] isEqualToString:@"regular"]) {
        return kRegularFontName;
    } else if ([[fontType lowercaseString] isEqualToString:@"bold"]) {
        return kBoldFontName;
    } else if ([[fontType lowercaseString] isEqualToString:@"light"]) {
        return kLightFontName;
    } else if ([[fontType lowercaseString] isEqualToString:@"medium"]) {
        return kMediumFontName;
    } else{
        return kRegularFontName;
    }
}

@implementation UIButton (TCCustomFont)

- (NSString *)fontName {
    return self.titleLabel.font.fontName;
}

- (void)setFontName:(NSString *)fontName {
    self.titleLabel.font = [UIFont fontWithName:fontName size:self.titleLabel.font.pointSize];
}

- (NSString *)fontType {
    return self.titleLabel.font.fontName;
}

- (void)setFontType:(NSString *)fontType {
    self.titleLabel.font = [UIFont fontWithName:fontNameFromType(fontType) size:self.titleLabel.font.pointSize];
}

@end

@implementation UILabel (TCCustomFont)

- (NSString *)fontName {
    return self.font.fontName;
}

- (void)setFontName:(NSString *)fontName {
    self.font = [UIFont fontWithName:fontName size:self.font.pointSize];
}

- (NSString *)fontType {
    return self.font.fontName;
}

- (void)setFontType:(NSString *)fontType {
    self.font = [UIFont fontWithName:fontNameFromType(fontType) size:self.font.pointSize];
}

@end

@implementation UITextField (TCCustomFont)

- (NSString *)fontName {
    return self.font.fontName;
}

- (void)setFontName:(NSString *)fontName {
    self.font = [UIFont fontWithName:fontName size:self.font.pointSize];
}

- (NSString *)fontType {
    return self.font.fontName;
}

- (void)setFontType:(NSString *)fontType {
    self.font = [UIFont fontWithName:fontNameFromType(fontType) size:self.font.pointSize];
}

-(BOOL)returnButton {
    return TRUE;
}

- (void)setReturnButton:(BOOL)returnButton {
    if (returnButton) {
        UIBarButtonItem *doneItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneButtonDidPressed:)];
        UIBarButtonItem *flexableItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:NULL];
        UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width, 44)];
        [toolbar setTintColor:[UIColor darkGrayColor]];
        [toolbar setBackgroundImage:[UIImage imageNamed:@"navBar"] forToolbarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
        [toolbar setItems:[NSArray arrayWithObjects:flexableItem,doneItem, nil]];
        self.inputAccessoryView = toolbar;
    }
}

- (void)doneButtonDidPressed:(id)sender {
    [self resignFirstResponder];
}

@end

@implementation UITextView (TCCustomFont)

- (NSString *)fontName {
    return self.font.fontName;
}

- (void)setFontName:(NSString *)fontName {
    self.font = [UIFont fontWithName:fontName size:self.font.pointSize];
}

- (NSString *)fontType {
    return self.font.fontName;
}

- (void)setFontType:(NSString *)fontType {
    self.font = [UIFont fontWithName:fontNameFromType(fontType) size:self.font.pointSize];
}

-(BOOL)returnButton {
    return TRUE;
}

- (void)setReturnButton:(BOOL)returnButton {
    if (returnButton) {
        UIBarButtonItem *doneItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneButtonDidPressed:)];
        UIBarButtonItem *flexableItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:NULL];
        UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width, 44)];
        [toolbar setTintColor:[UIColor darkGrayColor]];
        [toolbar setBackgroundImage:[UIImage imageNamed:@"navBar"] forToolbarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
        [toolbar setItems:[NSArray arrayWithObjects:flexableItem,doneItem, nil]];
        self.inputAccessoryView = toolbar;
    }
}

- (void)doneButtonDidPressed:(id)sender {
    [self resignFirstResponder];
}


@end


