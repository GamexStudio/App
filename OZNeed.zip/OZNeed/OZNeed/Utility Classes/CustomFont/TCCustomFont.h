//
//  TCCustomFont.h
//  EduCaching
//
//  Created on 16/06/15.
//
//

extern NSString *const kRegularFontName;
extern NSString *const kBoldFontName;
extern NSString *const kLightFontName;
extern NSString *const kMediumFontName;

NSString* fontNameFromType(NSString *fontType);

@interface UIButton (TCCustomFont)
@property (nonatomic, copy) NSString* fontName;
@property (nonatomic, copy) IBInspectable NSString* fontType;
@end

@interface UILabel (TCCustomFont)
@property (nonatomic, copy) NSString* fontName;
@property (nonatomic, copy) IBInspectable NSString* fontType;
@end

@interface UITextField (TCCustomFont)
@property (nonatomic, copy) NSString* fontName;
@property (nonatomic, copy) IBInspectable NSString* fontType;
@property (nonatomic, assign) IBInspectable BOOL returnButton;
@end

@interface UITextView (TCCustomFont)
@property (nonatomic, copy) NSString* fontName;
@property (nonatomic, copy) IBInspectable NSString* fontType;
@property (nonatomic, assign) IBInspectable BOOL returnButton;
@end