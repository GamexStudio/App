

#import <MapKit/MapKit.h>

/*!
 *  Custom Annotation View Class
 */
@interface VTAnnotationView : MKAnnotationView

@end
