//
//  VTAnnotationView.h
//  AnimationDemo1
//
//  Created by Martin on 2/10/15.
//  Copyright (c) 2015 Martin. All rights reserved.
//


#import <MapKit/MapKit.h>


/*!
 *  Custom MKAnnotation class for store more information about annotation.
 */
@interface VTAnnotation : NSObject <MKAnnotation>

/*!
 *  annotation coordinates.
 */
@property (nonatomic, assign) CLLocationCoordinate2D coordinate;

/*!
 *  Title for annotation pin.
 */
@property (nonatomic, copy) NSString *title;

/*!
 *  Sub Title for annotation pin.
 */
@property (nonatomic, copy) NSString *subtitle;

/*!
 *  ID for annotation. Use for uniqe identification of annotation. Auto Id will be genrate by:
 *  method [VTMapView getUniqueAnnotationId]
 */
@property (nonatomic, retain) NSString * ID;

/*!
 *  Annotation default image.
 */
@property (nonatomic, retain) UIImage * defaultImage;

/*!
 *  Annotation selected image.
 */
@property (nonatomic, retain) UIImage * selectedImage;

/*!
 *  Flag for show a callout view for annotation.
 */
@property (nonatomic, readwrite) BOOL canShowCallout;


@property (nonatomic, assign) NSInteger index;



+ (VTAnnotation *) annotationWithLatitude:(double) latitude longitude:(double)longitude title:(NSString*) title subTitle:(NSString*) subTitle defaultImage:(UIImage *) defaultImage selctedImage:(UIImage *) selectedImage annotationId:(NSString *) _id canShowCallout:(BOOL) canShow;
+ (VTAnnotation*) annotationWithCoordinate:(CLLocationCoordinate2D) coordinate title:(NSString*) title subTitle:(NSString*) subTitle defaultImage:(UIImage *) defaultImage selctedImage:(UIImage *) selectedImage annotationId:(NSString *) _id canShowCallout:(BOOL) canShow;

@end
