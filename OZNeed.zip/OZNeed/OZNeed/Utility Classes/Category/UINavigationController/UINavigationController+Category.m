
#import "UINavigationController+Category.h"

@implementation UINavigationController (Category)


- (id)popToViewControllerWithClassname:(NSString *)className Animated:(BOOL)animated {
    Class class =  NSClassFromString(className);
    for (UIViewController *controller in self.viewControllers) {
        if([controller isKindOfClass:class]) {
            [self popToViewController:controller animated:animated];
            return controller;
        }
    }
    return nil;
}


- (void)popOrPushToViewController:(UIViewController *)controller Animated:(BOOL)animated{
    for (UIViewController *controller in self.viewControllers) {
        if([controller isKindOfClass:[controller class]]) {
            [self popToViewController:controller animated:animated];
            break;
        }
    }
    [self pushViewController:controller animated:animated];
}
@end
