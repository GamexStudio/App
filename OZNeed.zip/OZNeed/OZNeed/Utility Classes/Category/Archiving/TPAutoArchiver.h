#import <Foundation/Foundation.h>

@interface TPAutoArchiver : NSObject
+ (void)archiveObject:(id)anObject
			withCoder:(NSCoder *)aCoder;
+ (void)unarchiveObject:(id)anObject
			  withCoder:(NSCoder *)aCoder;
@end

// Informal protocol for objects that wish to control which keys are serialized.
@interface NSObject (TPAutoArchiverKeyControl)
+ (NSArray *)autoArchiverKeysToExclude;
+ (NSArray *)autoArchiverKeysToAdd;
@end
