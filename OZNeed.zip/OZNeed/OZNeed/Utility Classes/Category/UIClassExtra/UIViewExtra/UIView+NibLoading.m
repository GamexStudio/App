//
//  UIView+NibLoading.m
//  lama
//
//  Created by mac on 14-5-5.
//  Copyright (c) 2014年 babytree. All rights reserved.
//

#import "UIView+NibLoading.h"
#import "UIView+Size.h"
@implementation UIView (NibLoading)


+ (id)loadWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)bundleOrNil owner:(id)owner
{
    //default values
    NSString *nibName = nibNameOrNil ?: NSStringFromClass(self);
    NSBundle *bundle = bundleOrNil ?: [NSBundle mainBundle];

    //cache nib to prevent unnecessary filesystem access
    static NSCache *nibCache = nil;
    if (nibCache == nil) {
        nibCache = [[NSCache alloc] init];
    }
    NSString *pathKey = [NSString stringWithFormat:@"%@.%@", bundle.bundleIdentifier, nibName];
    UINib *nib = [nibCache objectForKey:pathKey];
    if (nib == nil) {
        NSString *nibPath = [bundle pathForResource:nibName ofType:@"nib"];
        if (nibPath) nib = [UINib nibWithNibName:nibName bundle:bundle];
        [nibCache setObject:nib ?: [NSNull null] forKey:pathKey];
    }
    else if ([nib isKindOfClass:[NSNull class]]) {
        nib = nil;
    }

    if (nib) {
        //attempt to load from nib
        NSArray *contents = [nib instantiateWithOwner:owner options:nil];
        UIView *view = [contents count]? [contents objectAtIndex:0]: nil;
        NSAssert ([view isKindOfClass:self], @"First object in nib '%@' was '%@'. Expected '%@'", nibName, view, self);
        return view;
    }

    //return empty view
    return [[[self class] alloc] init];
}

- (void)loadWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)bundleOrNil {
    NSString *nibName = nibNameOrNil ?: NSStringFromClass([self class]);
    UIView *view = [UIView loadWithNibName:nibName bundle:bundleOrNil owner:self];
    if (view) {
        if (CGSizeEqualToSize(self.frame.size, CGSizeZero)) {
            //if we have zero size, set size from content
            self.size = view.size;
        }
        else {
            //otherwise set content size to match our size
            view.frame = self.contentBounds;
        }
        [self addSubview:view];
    }
}

@end
