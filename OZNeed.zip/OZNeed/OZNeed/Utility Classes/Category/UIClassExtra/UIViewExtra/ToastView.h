

#import <UIKit/UIKit.h>

@interface ToastView : UIView

/**
 *  ToastView Config
 */
+ (void)setAppearanceBackgroundColor:(UIColor *)backgroundColor;
+ (void)setAppearanceCornerRadius:(CGFloat)cornerRadius;
+ (void)setAppearanceMaxHeight:(CGFloat)maxHeight;
+ (void)setAppearanceMaxWidth:(CGFloat)maxWidth;
+ (void)setAppearanceOffsetBottom:(CGFloat)offsetBottom;
+ (void)setAppearanceTextAligment:(NSTextAlignment)textAlignment;
+ (void)setAppearanceTextColor:(UIColor *)textColor;
+ (void)setAppearanceTextFont:(UIFont *)textFont;
+ (void)setAppearanceTextPadding:(CGFloat)textPadding;
+ (void)setToastViewShowDuration:(NSTimeInterval)duration;

/**
 *  ToastView Show
 */
+ (void)show:(id)toast;
+ (void)show:(id)toast duration:(NSTimeInterval)duration;

+ (void)showInView:(UIView *)view toast:(id)toast;
+ (void)showInView:(UIView *)view toast:(id)toast duration:(NSTimeInterval)duration;
@end
