
#import <UIKit/UIKit.h>

@interface UIView (Size)
@property (nonatomic, assign) CGFloat x;
@property (nonatomic, assign) CGFloat y;
@property (nonatomic, assign) CGFloat width;
@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) CGFloat right;
@property (nonatomic, assign) CGFloat bottom;

@property (nonatomic, assign) CGPoint origin;
@property (nonatomic, assign) CGSize size;
@property (nonatomic, assign) CGFloat centerX;
@property (nonatomic, assign) CGFloat centerY;

//bounds accessors
@property (nonatomic, assign) CGSize boundsSize;
@property (nonatomic, assign) CGFloat boundsWidth;
@property (nonatomic, assign) CGFloat boundsHeight;

//content getters
@property (nonatomic, readonly) CGRect contentBounds;
@property (nonatomic, readonly) CGPoint contentCenter;


#pragma mark - Positioning

- (void) moveBottomOf:(UIView *)targetView margin:(CGFloat)margin;
- (void) moveRightOf:(UIView *)targetView margin:(CGFloat)margin;
- (void) moveCenterHorizontalOf:(UIView *)targetView;
- (void) moveCenterVerticalOf:(UIView *)targetView;
- (void) moveBottomRightCorner:(UIView *)targetView margin:(CGFloat)margin;
- (void) moveTopRightCorner:(UIView *)targetView margin:(CGFloat)margin;
- (void) centerHorizontallyBelow:(UIView *)view padding:(CGFloat)padding;
- (void) centerHorizontallyBelow:(UIView *)view;



- (void) centerInRect:(CGRect)rect;
- (void) centerInRect:(CGRect)rect leftOffset:(CGFloat)left;
- (void) centerInRect:(CGRect)rect topOffset:(CGFloat)top;
- (void) centerVerticallyInRect:(CGRect)rect;
- (void) centerVerticallyInRect:(CGRect)rect left:(CGFloat)left;
- (void) centerHorizontallyInRect:(CGRect)rect;
- (void) centerHorizontallyInRect:(CGRect)rect top:(CGFloat)top;

- (void) centerInSuperView;
- (void) centerInSuperViewWithLeftOffset:(CGFloat)left;
- (void) centerInSuperViewWithTopOffset:(CGFloat)top;
- (void) centerVerticallyInSuperView;
- (void) centerVerticallyInSuperViewWithLeft:(CGFloat)left;
- (void) centerHorizontallyInSuperView;
- (void) centerHorizontallyInSuperViewWithTop:(CGFloat)top;



@end






