

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

typedef enum {
    kAnimateFromTop          = 0,
    kAnimateFromBottom       = 1,
    kAnimateFromLeft         = 2,
    kAnimateFromRight        = 3,
} AnimationDirection;

@interface UIView (SubView)

#pragma mark - Add Subviews with animation

- (void)addSubview:(UIView *)view animationDirection:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion;
- (void)addSubview:(UIView *)view frame:(CGRect)frame animationDirection:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion;
- (void)addSubview:(UIView *)view  animations:(void (^)(void))animations animationDirection:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion;

- (void)insertSubview:(UIView *)view atIndex:(NSInteger)index animationDirection:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion;

- (void)removeFromSuperview:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion;
- (void)removeFromSuperview:(void (^)(void))animations animationDirection:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion;


- (void)slideView:(AnimationDirection)animationDirection duration:(NSTimeInterval)duration completion:(void (^)(void))completion;


#pragma mark - Get Subviews


@property (nonatomic, readonly) UIViewController *viewController;
@property (nonatomic, readonly) NSInteger subviewIndex;

- (void)addSubviewToBack:(UIView*)view;

- (UIView *)superviewWithClass:(Class)aClass; // strict:NO
- (UIView *)superviewWithClass:(Class)aClass strict:(BOOL)strict;

- (UIView *)descendantOrSelfWithClass:(Class)aClass; // strict:NO
- (UIView *)descendantOrSelfWithClass:(Class)aClass strict:(BOOL)strict;

- (void)removeAllSubviews;

- (void)bringToFront;
- (void)sendToBack;

- (void)bringOneLevelUp;
- (void)sendOneLevelDown;

- (BOOL)isInFront;
- (BOOL)isAtBack;

- (void)swapDepthsWithView:(UIView*)swapView;


// view searching

- (UIView *)viewMatchingPredicate:(NSPredicate *)predicate;
- (UIView *)viewWithTag:(NSInteger)tag ofClass:(Class)viewClass;
- (UIView *)viewOfClass:(Class)viewClass;
- (NSArray *)viewsMatchingPredicate:(NSPredicate *)predicate;
- (NSArray *)viewsWithTag:(NSInteger)tag;
- (NSArray *)viewsWithTag:(NSInteger)tag ofClass:(Class)viewClass;
- (NSArray *)viewsOfClass:(Class)viewClass;

- (UIView *)firstSuperviewMatchingPredicate:(NSPredicate *)predicate;
- (UIView *)firstSuperviewOfClass:(Class)viewClass;
- (UIView *)firstSuperviewWithTag:(NSInteger)tag;
- (UIView *)firstSuperviewWithTag:(NSInteger)tag ofClass:(Class)viewClass;

- (BOOL)viewOrAnySuperviewMatchesPredicate:(NSPredicate *)predicate;
- (BOOL)viewOrAnySuperviewIsKindOfClass:(Class)viewClass;
- (BOOL)isSuperviewOfView:(UIView *)view;
- (BOOL)isSubviewOfView:(UIView *)view;

- (UIView *)firstResponder;

@end
