//
//  NSString+extras.m
//
//  Created on 18/08/11.
//  Copyright 2011. All rights reserved.
//

#import "UIView+Language.h"
#import "UIView+Size.h"

@implementation UIView (Language)

//Private method Don't declare in .h file
- (void)updateFrame {
//    self.transform = CGAffineTransformMakeScale(-1,1);
    self.x = self.superview.width - self.width-self.x - self.rightMargin;
    if ([self isKindOfClass:[UILabel class]]) {
        UILabel *lbl = (UILabel *)self;
        if ([lbl textAlignment] == NSTextAlignmentLeft) {
            [lbl setTextAlignment:NSTextAlignmentRight];
        }else if ([lbl textAlignment] == NSTextAlignmentRight){
            [lbl setTextAlignment:NSTextAlignmentLeft];
        }
    }
    if ([self isKindOfClass:[UITextField class]]) {
        UITextField *txtField = (UITextField *)self;
        if ([txtField textAlignment] == NSTextAlignmentLeft) {
            [txtField setTextAlignment:NSTextAlignmentRight];
        }else if ([txtField textAlignment] == NSTextAlignmentRight){
            [txtField setTextAlignment:NSTextAlignmentLeft];
        }
    }
    if ([self isKindOfClass:[UIButton class]]) {
        UIButton *btn = (UIButton *)self;
        if (btn.contentHorizontalAlignment == UIControlContentHorizontalAlignmentLeft) {
            [btn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];
        }else if (btn.contentHorizontalAlignment == UIControlContentHorizontalAlignmentRight){
            [btn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
        }
    }
}

/*- (void)updateForSelectedLangauge{
    for (UIView *subView in self.subviews) {
        if (!subView.noNeedToUpdateFrame) {
            if (IsArabicSelected) {
                if (![subView IsUpdateForArabic]) {
                    [subView setIsUpdateForArabic:TRUE];
                    [subView updateFrame];
                }
            }else{
                if ([subView IsUpdateForArabic]) {
                    [subView setIsUpdateForArabic:FALSE];
                    [subView updateFrame];
                }
            }
            if ([subView isKindOfClass:[UIView class]] && !subView.noNeedToUpdateFrame) {
                [subView updateForSelectedLangauge];
            }
        }
    }
}*/


- (void)setIsUpdateForArabic:(BOOL)isUpdateForArabic{
    objc_setAssociatedObject(self, @"isUpdateForArabic", @(isUpdateForArabic), OBJC_ASSOCIATION_ASSIGN);
}

- (BOOL)IsUpdateForArabic{
    return [objc_getAssociatedObject(self, @"isUpdateForArabic") boolValue];
}

- (void)setNoNeedToUpdateFrame:(BOOL)noNeedToUpdateFrame {
    objc_setAssociatedObject(self, @"noNeedToUpdateFrame", @(noNeedToUpdateFrame), OBJC_ASSOCIATION_ASSIGN);
}

- (BOOL)noNeedToUpdateFrame {
    return [objc_getAssociatedObject(self, @"noNeedToUpdateFrame") boolValue];
}

- (void)setRightMargin:(CGFloat)rightMargin {
    objc_setAssociatedObject(self, @"rightMarginValue", @(rightMargin), OBJC_ASSOCIATION_RETAIN_NONATOMIC);

}

- (CGFloat)rightMargin {
   //NSLog(@"%f",[objc_getAssociatedObject(self, @"rightMarginValue") floatValue]);
    return [objc_getAssociatedObject(self, @"rightMarginValue") floatValue];
}


@end
