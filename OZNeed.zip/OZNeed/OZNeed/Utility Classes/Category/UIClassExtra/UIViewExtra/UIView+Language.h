//
//  NSString+extras.h
//
//  Created on 18/08/11.
//  Copyright 2011. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <objc/runtime.h>

@interface UIView (Language)

@property (nonatomic, assign) BOOL      IsUpdateForArabic;

// set noNeedToUpdateFrame = true if this view's subview frame is  not require to update for arabic language
@property (nonatomic, assign) BOOL      noNeedToUpdateFrame;

@property (nonatomic, assign) CGFloat   rightMargin;

//- (void)updateForSelectedLangauge;
@end
