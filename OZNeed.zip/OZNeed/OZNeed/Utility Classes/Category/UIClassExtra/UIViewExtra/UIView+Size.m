
#import "UIView+Size.h"

@implementation UIView (Size)

-(CGFloat) x {
    return self.frame.origin.x;
}

-(void) setX:(CGFloat) newX {
    CGRect frame = self.frame;
    frame.origin.x = newX;
    self.frame = frame;
}

-(CGFloat) y {
    return self.frame.origin.y;
}

-(void) setY:(CGFloat) newY {
    CGRect frame = self.frame;
    frame.origin.y = newY;
    self.frame = frame;
}

-(CGFloat) width {
    return self.frame.size.width;
}

-(void) setWidth:(CGFloat) newWidth {
    CGRect frame = self.frame;
    frame.size.width = newWidth;
    self.frame = frame;
}

-(CGFloat) height {
    return self.frame.size.height;
}

-(void) setHeight:(CGFloat) newHeight {
    CGRect frame = self.frame;
    frame.size.height = newHeight;
    self.frame = frame;
}

-(CGFloat)right {
    return self.frame.origin.x + self.frame.size.width;
}

- (void)setRight:(CGFloat)right {
    CGRect frame = self.frame;
    frame.origin.x = self.superview.frame.size.width - self.frame.size.width - right;
    self.frame = frame;

}

- (CGFloat)bottom {
    return self.frame.origin.y + self.frame.size.height;
}

- (void)setBottom:(CGFloat)bottom {
    CGRect frame = self.frame;
    frame.origin.y = self.superview.frame.size.height - self.frame.size.height - bottom;
    self.frame = frame;
}

- (void)setSize:(CGSize)size;
{
  CGPoint origin = [self frame].origin;

  [self setFrame:CGRectMake(origin.x, origin.y, size.width, size.height)];
}

- (CGSize)size;
{
  return [self frame].size;
}

- (void)setOrigin:(CGPoint)origin
{
    CGRect frame = self.frame;
    frame.origin = origin;
    self.frame = frame;
}

- (CGPoint)origin
{
    return self.frame.origin;
}


- (CGFloat)centerX;
{
  return [self center].x;
}

- (void)setCenterX:(CGFloat)centerX;
{
  [self setCenter:CGPointMake(centerX, self.center.y)];
}

- (CGFloat)centerY;
{
  return [self center].y;
}

- (void)setCenterY:(CGFloat)centerY;
{
  [self setCenter:CGPointMake(self.center.x, centerY)];
}


// bounds accessors

- (CGSize)boundsSize
{
    return self.bounds.size;
}

- (void)setBoundsSize:(CGSize)size
{
    CGRect bounds = self.bounds;
    bounds.size = size;
    self.bounds = bounds;
}

- (CGFloat)boundsWidth
{
    return self.boundsSize.width;
}

- (void)setBoundsWidth:(CGFloat)width
{
    CGRect bounds = self.bounds;
    bounds.size.width = width;
    self.bounds = bounds;
}

- (CGFloat)boundsHeight
{
    return self.boundsSize.height;
}

- (void)setBoundsHeight:(CGFloat)height
{
    CGRect bounds = self.bounds;
    bounds.size.height = height;
    self.bounds = bounds;
}

// content getters

- (CGRect)contentBounds
{
    return CGRectMake(0.0f, 0.0f, self.boundsWidth, self.boundsHeight);
}

- (CGPoint)contentCenter
{
    return CGPointMake(self.boundsWidth/2.0f, self.boundsHeight/2.0f);
}

- (void)moveBottomOf:(UIView *)targetView margin:(CGFloat)margin{
    [self setFrame: CGRectMake(
                               self.frame.origin.x,
                               targetView.frame.origin.y + targetView.frame.size.height + margin,
                               self.frame.size.width,
                               self.frame.size.height
                               )];
}

- (void)moveRightOf:(UIView *)targetView margin:(CGFloat)margin{
    [self setFrame: CGRectMake(
                               targetView.frame.origin.x + targetView.frame.size.width + margin,
                               self.frame.origin.y,
                               self.frame.size.width,
                               self.frame.size.height
                               )];
}


- (void) moveCenterHorizontalOf:(UIView *)targetView{
    [self setFrame: CGRectMake(
                               ( targetView.frame.size.width - self.frame.size.width  )/2,
                               self.frame.origin.y,
                               self.frame.size.width,
                               self.frame.size.height
                               )];
}

- (void)moveCenterVerticalOf:(UIView *)targetView {
    [self setFrame: CGRectMake(
                               self.frame.origin.x,
                               ( targetView.frame.size.height - self.frame.size.height)/2,
                               self.frame.size.width,
                               self.frame.size.height
                               )];
}

- (void) moveBottomRightCorner:(UIView *)targetView margin:(CGFloat)margin{
    [self setFrame: CGRectMake(
                               targetView.frame.size.width
                               - self.frame.size.width - margin,
                               targetView.frame.size.height
                               - self.frame.size.height - margin,
                               self.frame.size.width,
                               self.frame.size.height
                               )];
}

- (void) moveTopRightCorner:(UIView *)targetView
                     margin:(CGFloat)margin{
    [self setFrame: CGRectMake(
                               targetView.frame.size.width
                               - self.frame.size.width - margin,
                               self.frame.size.height - margin,
                               self.frame.size.width,
                               self.frame.size.height
                               )];
}

- (void)centerHorizontallyBelow:(UIView *)view padding:(CGFloat)padding
{
    // for now, could use screen relative positions.
    NSAssert([self superview] == [view superview], @"views must have the same parent");

    [self setCenter:CGPointMake([view center].x,
                                floorf(padding + CGRectGetMaxY([view frame]) + ([self height] / 2)))];
}

- (void)centerHorizontallyBelow:(UIView *)view
{
    [self centerHorizontallyBelow:view padding:0];
}

#pragma mark - Positioning
- (void)centerInRect:(CGRect)rect
{
    [self setCenter:CGPointMake(floorf(CGRectGetMidX(rect)) + ((int)floorf([self width]) % 2 ? .5 : 0) , floorf(CGRectGetMidY(rect)) + ((int)floorf([self height]) % 2 ? .5 : 0))];
}

- (void)centerInRect:(CGRect)rect leftOffset:(CGFloat)left
{
    [self setCenter:CGPointMake(left + floorf(CGRectGetMidX(rect)) + ((int)floorf([self width]) % 2 ? .5 : 0) , floorf(CGRectGetMidY(rect)) + ((int)floorf([self height]) % 2 ? .5 : 0))];
}

- (void)centerInRect:(CGRect)rect topOffset:(CGFloat)top
{
    [self setCenter:CGPointMake(floorf(CGRectGetMidX(rect)) + ((int)floorf([self width]) % 2 ? .5 : 0) , top + floorf(CGRectGetMidY(rect)) + ((int)floorf([self height]) % 2 ? .5 : 0))];
}

- (void)centerVerticallyInRect:(CGRect)rect
{
    [self setCenter:CGPointMake([self center].x, floorf(CGRectGetMidY(rect)) + ((int)floorf([self height]) % 2 ? .5 : 0))];
}

- (void)centerVerticallyInRect:(CGRect)rect left:(CGFloat)left
{


    [self centerVerticallyInRect:rect];
    self.x = left;
}

- (void)centerHorizontallyInRect:(CGRect)rect
{
    [self setCenter:CGPointMake(floorf(CGRectGetMidX(rect)) + ((int)floorf([self width]) % 2 ? .5 : 0), [self center].y)];
}

- (void)centerHorizontallyInRect:(CGRect)rect top:(CGFloat)top
{
    [self centerHorizontallyInRect:rect];
    self.y = top;
}

- (void)centerInSuperView
{
    [self centerInRect:[[self superview] bounds]];
}

- (void)centerInSuperViewWithLeftOffset:(CGFloat)left
{
    [self centerInRect:[[self superview] bounds] leftOffset:left];
}

- (void)centerInSuperViewWithTopOffset:(CGFloat)top
{
    [self centerInRect:[[self superview] bounds] topOffset:top];
}

- (void)centerVerticallyInSuperView
{
    [self centerVerticallyInRect:[[self superview] bounds]];
}

- (void)centerVerticallyInSuperViewWithLeft:(CGFloat)left
{
    [self centerVerticallyInRect:[[self superview] bounds] left:left];
}

- (void)centerHorizontallyInSuperView
{
    [self centerHorizontallyInRect:[[self superview] bounds]];
}

- (void)centerHorizontallyInSuperViewWithTop:(CGFloat)top
{
    [self centerHorizontallyInRect:[[self superview] bounds] top:top];
}



@end
