
#import "ToastView.h"

#define TOAST_VIEW_ANIMATION_DURATION  0.5f
#define TOAST_VIEW_OFFSET_BOTTOM  61.0f
#define TOAST_VIEW_OFFSET_LEFT_RIGHT  8.0f
#define TOAST_VIEW_OFFSET_TOP  76.0f
#define TOAST_VIEW_SHOW_DURATION  3.0f
#define TOAST_VIEW_TAG 1024
#define TOAST_VIEW_TEXT_FONT_SIZE  14.0f
#define TOAST_VIEW_TEXT_PADDING  8.0f
#define TOAST_VIEW_BACKGROUND_COLOR [[UIColor blackColor] colorWithAlphaComponent:0.6]
#define TOAST_VIEW_TEXT_COLOR [UIColor whiteColor]

static UIColor *_backgroundColor = nil;
static UIColor *_textColor = nil;
static UIFont *_textFont = nil;
static CGFloat _cornerRadius = 0.0f;
static CGFloat _duration = TOAST_VIEW_SHOW_DURATION;
static CGFloat _maxWidth = 0.0f;
static CGFloat _maxHeight = 0.0f;
static CGFloat _offsetBottom = TOAST_VIEW_OFFSET_BOTTOM;
static CGFloat _offsetTop = TOAST_VIEW_OFFSET_TOP;
static CGFloat _textPadding = TOAST_VIEW_TEXT_PADDING;
static NSTextAlignment _textAligment = NSTextAlignmentCenter;

@interface ToastView ()

@end

@implementation ToastView

#pragma mark - ToastView Config

+ (void)setAppearanceBackgroundColor:(UIColor *)backgroundColor {
	_backgroundColor = [backgroundColor copy];
    
}

+ (void)setAppearanceCornerRadius:(CGFloat)cornerRadius {
	_cornerRadius = cornerRadius;
}

+ (void)setAppearanceMaxHeight:(CGFloat)maxHeight {
	_maxHeight = maxHeight;
}

+ (void)setAppearanceMaxWidth:(CGFloat)maxWidth {
	_maxWidth = maxWidth;
}

+ (void)setAppearanceOffsetBottom:(CGFloat)offsetBottom {
	_offsetBottom = offsetBottom;
}

+ (void)setAppearanceTextAligment:(NSTextAlignment)textAlignment {
	_textAligment = textAlignment;
}

+ (void)setAppearanceTextColor:(UIColor *)textColor {
	_textColor = [textColor copy];
}

+ (void)setAppearanceTextFont:(UIFont *)textFont {
	_textFont = [textFont copy];
}

+ (void)setAppearanceTextPadding:(CGFloat)textPadding {
	_textPadding = textPadding;
}

+ (void)setToastViewShowDuration:(NSTimeInterval)duration {
	_duration = duration;
}

#pragma mark - ToastView Show

+ (void)show:(id)toast {
	[ToastView show:toast duration:_duration];
}

+ (void)show:(id)toast duration:(NSTimeInterval)duration {
    [self showInView:nil toast:toast duration:duration];
}

+ (void)showInView:(UIView *)view toast:(id)toast {
    [self showInView:nil toast:toast duration:_duration];
}

+ (void)showInView:(UIView *)view toast:(id)toast duration:(NSTimeInterval)duration {
    NSString *toastText = [NSString stringWithFormat:@"%@", toast];
    if (toastText.length < 1) {
        return;
    }
    __block UIView *viewContainer = view;
    dispatch_async(dispatch_get_main_queue(), ^{
        if(!viewContainer) {
            viewContainer = [self _keyWindowView];
        }
        if (!viewContainer) {
            return;
        }
        
        UIView *toastView = [UIView new];
        toastView.translatesAutoresizingMaskIntoConstraints = NO;
        toastView.userInteractionEnabled = NO;
        toastView.backgroundColor = [self _backgroundColor];
        toastView.tag = TOAST_VIEW_TAG;
        toastView.layer.cornerRadius = _cornerRadius;
        toastView.clipsToBounds = YES;
        toastView.alpha = 0.0f;
        
        UILabel *toastLabel = [UILabel new];
        toastLabel.translatesAutoresizingMaskIntoConstraints = NO;
        toastLabel.font = [self _textFont];
        toastLabel.text = toastText;
        toastLabel.textColor = [self _textColor];
        toastLabel.textAlignment = _textAligment;
        toastLabel.numberOfLines = 0;
        
        [[viewContainer viewWithTag:TOAST_VIEW_TAG] removeFromSuperview];
        
        CGSize toastLabelSize = [toastLabel sizeThatFits:CGSizeMake([self _maxWidth] - _textPadding * 2.0f, [self _maxHeight] - _textPadding * 2.0f)];
        CGFloat toastViewWidth = toastLabelSize.width + _textPadding * 2.0f;
        CGFloat toastViewHeight = toastLabelSize.height + _textPadding * 2.0f;
        
        if (toastViewWidth > _maxWidth) {
            toastViewWidth = _maxWidth;
        }
        
        if (toastViewHeight > _maxWidth) {
            toastViewHeight = _maxHeight;
        }
        
        NSDictionary *views = NSDictionaryOfVariableBindings(toastLabel, toastView);
        
        [toastView addSubview:toastLabel];
        [viewContainer addSubview:toastView];
        
        [toastView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:|-(%@)-[toastLabel]-(%@)-|", @(_textPadding), @(_textPadding)]
                                                                          options:0
                                                                          metrics:nil
                                                                            views:views]];
        [toastView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:|-(%@)-[toastLabel]-(%@)-|", @(_textPadding), @(_textPadding)]
                                                                          options:0
                                                                          metrics:nil
                                                                            views:views]];
        
        [viewContainer addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:[toastView(%@)]", @(toastViewWidth)]
                                                                              options:0
                                                                              metrics:nil
                                                                                views:views]];
        [viewContainer addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:|-(>=%@)-[toastView(<=%@)]-(%@)-|", @(_offsetTop), @(toastViewHeight), @(_offsetBottom)]
                                                                              options:0
                                                                              metrics:nil
                                                                                views:views]];
        [viewContainer addConstraint:[NSLayoutConstraint constraintWithItem:toastView
                                                                  attribute:NSLayoutAttributeCenterX
                                                                  relatedBy:NSLayoutRelationEqual
                                                                     toItem:viewContainer
                                                                  attribute:NSLayoutAttributeCenterX
                                                                 multiplier:1.0f
                                                                   constant:0.0f]];
        
        [UIView animateWithDuration:TOAST_VIEW_ANIMATION_DURATION animations: ^{
            toastView.alpha = 1.0f;
        }];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(duration * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [UIView animateWithDuration:TOAST_VIEW_ANIMATION_DURATION animations: ^{
                toastView.alpha = 0.0f;
            } completion: ^(BOOL finished) {
                [toastView removeFromSuperview];
            }];
        });
    });
}

#pragma mark - Private Methods

+ (UIFont *)_textFont {
	if (_textFont == nil) {
		_textFont = [UIFont systemFontOfSize:TOAST_VIEW_TEXT_FONT_SIZE];
	}
	return _textFont;
}

+ (UIColor *)_textColor {
	if (_textColor == nil) {
		_textColor = TOAST_VIEW_TEXT_COLOR;
	}
	return _textColor;
}

+ (UIColor *)_backgroundColor {
	if (_backgroundColor == nil) {
		_backgroundColor = TOAST_VIEW_BACKGROUND_COLOR;
	}
	return _backgroundColor;
}

+ (CGFloat)_maxHeight {
	if (_maxHeight <= 0) {
		_maxHeight = [self _portraitScreenHeight] - (_offsetBottom + TOAST_VIEW_OFFSET_TOP);
	}

	return _maxHeight;
}

+ (CGFloat)_maxWidth {
	if (_maxWidth <= 0) {
		_maxWidth = [self _portraitScreenWidth] - (TOAST_VIEW_OFFSET_LEFT_RIGHT + TOAST_VIEW_OFFSET_LEFT_RIGHT);
	}
	return _maxWidth;
}

+ (CGFloat)_portraitScreenWidth {
	return UIInterfaceOrientationIsPortrait([UIApplication sharedApplication].statusBarOrientation) ? CGRectGetWidth([UIScreen mainScreen].bounds) : CGRectGetHeight([UIScreen mainScreen].bounds);
}

+ (CGFloat)_portraitScreenHeight {
	return UIInterfaceOrientationIsPortrait([UIApplication sharedApplication].statusBarOrientation) ? CGRectGetHeight([UIScreen mainScreen].bounds) : CGRectGetWidth([UIScreen mainScreen].bounds);
}

+ (UIView *)_keyWindowView {
#ifndef IS_APP_EXTENSION
	UIWindow *window = [UIApplication sharedApplication].keyWindow;
	if (!window)
		window = [[UIApplication sharedApplication].windows firstObject];
	return [[window subviews] firstObject];
#endif
    return nil;
}

@end
