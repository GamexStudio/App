

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
@interface UITextView (Category) <UITextViewDelegate>

@property (nonatomic, strong) UITextView *placeHolderTextView;

@property (nonatomic) IBInspectable NSInteger maxLength;
@property (nonatomic, strong) IBInspectable NSString *allowCharater;
@property (nonatomic, strong) IBInspectable NSString *disAllowCharater;
@property (nonatomic, retain) IBInspectable NSString *placeHolder;

@end
