
#import "UITextField+Category.h"
#import <objc/runtime.h>

static NSString * const INZMaxLengthKey         = @"INZMaxLengthKey";
static NSString * const INZAllowCharacterKey    = @"INZAllowCharacterKey";
static NSString * const INZDisAllowCharacterKey = @"INZDisAllowCharacterKey";

@implementation UITextField (Category)

@dynamic maxLength;
@dynamic allowCharater;
@dynamic disAllowCharater;
@dynamic placeholderColor;

#pragma mark - Getter

- (NSInteger)maxLength
{
    NSValue *maxLengthValue = objc_getAssociatedObject(self, &INZMaxLengthKey);
    if (maxLengthValue) {
        NSInteger maxLength;
        [maxLengthValue getValue:&maxLength];
        return maxLength;
    }
    
    return NSIntegerMax;
}

- (NSString *)allowCharater {
    return objc_getAssociatedObject(self, &INZAllowCharacterKey);
}

- (NSString *)disAllowCharater {
    return objc_getAssociatedObject(self, &INZDisAllowCharacterKey);
}

#pragma mark - Setter

- (void)setMaxLength:(NSInteger)maxLength
{
    if (maxLength < 1) {
        maxLength = NSIntegerMax;
    }
    
    NSValue *value = [NSValue value:&maxLength withObjCType:@encode(NSInteger)];
    objc_setAssociatedObject(self, &INZMaxLengthKey, value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    [self textFieldTextChanged:self];
    [self removeTarget:self
                action:@selector(textFieldTextChanged:)
      forControlEvents:UIControlEventEditingChanged];
    [self addTarget:self
             action:@selector(textFieldTextChanged:)
   forControlEvents:UIControlEventEditingChanged];
}

- (void)setAllowCharater:(NSString *)allowCharater {
    if (allowCharater.length > 0) {
        objc_setAssociatedObject(self, &INZAllowCharacterKey, allowCharater, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
}

- (void)setDisAllowCharater:(NSString *)disAllowCharater {
    if (disAllowCharater.length > 0) {
        objc_setAssociatedObject(self, &INZDisAllowCharacterKey, disAllowCharater, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
}

- (void)setPlaceholderColor:(UIColor *)placeholderColor {
    NSAttributedString *str = [[NSAttributedString alloc] initWithString:self.placeholder attributes:@{ NSForegroundColorAttributeName:placeholderColor}];
    [self setAttributedPlaceholder:str];
}

#pragma mark - Event

- (void)textFieldTextChanged:(UITextField *)textField{
   
    if (self.allowCharater.length > 0) {
        NSCharacterSet *allowCharSet = [NSCharacterSet characterSetWithCharactersInString:self.allowCharater];
        NSCharacterSet *disAllowCharSet = [[NSCharacterSet characterSetWithCharactersInString:self.allowCharater] invertedSet];
        if ([[self lastCharacter] rangeOfCharacterFromSet:allowCharSet options:NSCaseInsensitiveSearch].location == NSNotFound) {
            textField.text = [textField.text stringByTrimmingCharactersInSet:disAllowCharSet];
        }
    }else if (self.disAllowCharater.length > 0) {
        NSCharacterSet *disAllowCharSet = [NSCharacterSet characterSetWithCharactersInString:self.disAllowCharater] ;
        if ([[self lastCharacter] rangeOfCharacterFromSet:disAllowCharSet options:NSCaseInsensitiveSearch].location != NSNotFound) {
            textField.text = [textField.text stringByTrimmingCharactersInSet:disAllowCharSet];
        }
        
    }
    
    NSInteger adaptedLength = MIN(textField.text.length, textField.maxLength);
    NSRange range = NSMakeRange(0, adaptedLength);

    textField.text = [textField.text substringWithRange:range];
}

- (NSString *)lastCharacter {
    if ([self.text length] > 0) {
        NSString *lastChar = [self.text substringFromIndex:[self.text length] - 1];
        return lastChar;
    }
    return @"";
}

@end
