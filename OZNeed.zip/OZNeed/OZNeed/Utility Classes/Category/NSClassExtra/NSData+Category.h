//
//  NSData+Category.h
//
//
//  Created by qq on 12-6-11.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface NSData (Category)

+ (id)dataWithBase64EncodedString:(NSString *)string; // Padding '=' characters are optional. Whitespace is ignored.
- (NSString *)base64Encoding;

- (NSString *)stringValue;
- (UIImage *)image;
- (UIImage *)imageWithScale:(CGFloat)scale;

- (NSString *)APNSToken;
@end



