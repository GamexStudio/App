
#import <Foundation/Foundation.h>
#import "StoreKit/StoreKit.h"

@protocol IAPTransactionDelegate;

typedef void (^RequestProductsSuccessBlock)(NSArray * products);
typedef void (^RequestProductsFailureBlock)(NSArray * products);
typedef void (^PaymentTransactionSuccessBlock)(SKPaymentTransaction *transaction);
typedef void (^PaymentTransactionFailureBlock)(SKPaymentTransaction *transaction, NSError *error);
typedef void (^RestoreTransactionSuccessBlock)(NSArray *transactions);
typedef void (^RestoreTransactionFailureBlock)(NSArray *transactions, NSError *error);


@interface IAPHelper : NSObject <SKProductsRequestDelegate, SKPaymentTransactionObserver>

@property (nonatomic,strong) SKProductsRequest *request;

+ (IAPHelper *) sharedInstance;
- (void)requestProductsWithProductIdentifiers:(NSSet *)productIdentifiers success:(RequestProductsSuccessBlock)success failure:(RequestProductsFailureBlock)failure;
- (void)addPayment:(SKProduct *)product success:(PaymentTransactionSuccessBlock)success failure:(PaymentTransactionFailureBlock)failure;
- (void)restoreTranscationWithSuccess:(RestoreTransactionSuccessBlock)success failure:(RestoreTransactionFailureBlock)failure;

- (void)buyProductWithProductIdentifier:(NSString *)productIdentifier success:(PaymentTransactionSuccessBlock)success failure:(PaymentTransactionFailureBlock)failure;


@end
