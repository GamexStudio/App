//
//  TopNavBarView.m
//  IndiaMLS
//
//  Created by Martin on 30/12/15.
//
//

#import "TopNavBarView.h"
#import "CommonVaribles.h"
#import "UIView+Size.h"
#import "CommonHeaders.h"


@interface TopNavBarView ()

@property (nonatomic, copy) TopSearchTextChangeBlock searchTextDidChange;
@property (nonatomic, copy) TopSearchPressSearchBlock pressSearchButton;
@property (nonatomic, copy) TopSearchCancelSearchBlock pressCancelButton;

@end

@implementation TopNavBarView

+ (TopNavBarView *) getTopNavBarView {
    TopNavBarView * topView = [[TopNavBarView alloc] initWithNibName:@"TopNavBarView" bundle:[NSBundle mainBundle]];
    topView.view.frame = CGRectMake(0, 0, SCREEN_WIDTH(), 64);
    return topView;
}

- (void) viewDidLoad {
    
    [_viewCenterTitle setCenterX:self.view.center.x];
    
    [super viewDidLoad];
    [self loadLayout];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
  
  
}

- (void)loadLayout {
    [self.view setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    //[self.view setBackgroundColor:[UIColor colorWithHexString:@"F1606F"]];
    
   // [_lblTitle setTextAlignment:NSTextAlignmentCenter];
    [_lblTitle setTextColor:[UIColor whiteColor]];
    [_lblTitle setBackgroundColor:[UIColor clearColor]];
    
    // default hide search view.
    [searchView setHidden:YES];
    [searchView setBackgroundColor:self.view.backgroundColor];
    searchBar.delegate = self;    
   // [searchBar alwaysEnableSearch];
   // [searchBar setBarTintColor:defaultRedColor()];
    //[[UITextField appearanceWhenContainedIn:[UISearchBar class], nil] setTextColor:defaultRedColor()];
    
    // default Hide User Details.
    [_userDetails setHidden:YES];
    
    // Search Bar.
    /*[[UIBarButtonItem appearanceWhenContainedIn:[UISearchBar class], nil]
     setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                             [UIColor whiteColor],NSForegroundColorAttributeName,
                             [NSValue valueWithUIOffset:UIOffsetMake(0, 1)],NSForegroundColorAttributeName,nil] forState:UIControlStateNormal];*/
}

- (void) setDelegate:(id<TopNavBarViewDelegate>)delegate {
    _delegate = delegate;
}

-(void)setLayoutForCenterTitle{
    CGFloat width = [_lblnavTitle.text sizeForMaxWidth:self.view.width/3 withFont:_lblnavTitle.font].width;
    
    [self.viewCenterTitle setWidth: width + _imgdownarrow.size.width + 2];
    [self.viewCenterTitle setCenterX:self.view.centerX];
    [_lblnavTitle setWidth:width];
    [_imgdownarrow moveRightOf:self.lblnavTitle margin:3.0];
}

#pragma mark - Utility Methods

- (void)setLeftBarButtons:(NSArray *)leftBarButtons {
    [self setBarButtons:leftBarButtons withButtonWidth:kNavBarButtonWidth withButtonHeight:kNavBarButtonHeight inView:leftBtnView];
}

- (void)setRightBarButtons:(NSArray *)rightBarButtons {
    [self setBarButtons:rightBarButtons withButtonWidth:kNavBarButtonWidth withButtonHeight:kNavBarButtonHeight inView:rightBtnView];
}

- (void)setLeftBarButtons:(NSArray *)leftBarButtons withButtonWidth:(CGFloat) width {
    [self setBarButtons:leftBarButtons withButtonWidth:width withButtonHeight:kNavBarButtonHeight inView:leftBtnView];
}

- (void)setRightBarButtons:(NSArray *)rightBarButtons withButtonWidth:(CGFloat) width {
    [self setBarButtons:rightBarButtons withButtonWidth:width withButtonHeight:kNavBarButtonHeight inView:rightBtnView];
}

- (void)setLeftBarButtons:(NSArray *)leftBarButtons withButtonSize:(CGSize) size {
    [self setBarButtons:leftBarButtons withButtonWidth:size.width withButtonHeight:size.height inView:leftBtnView];
}

- (void)setRightBarButtons:(NSArray *)rightBarButtons withButtonSize:(CGSize) size {
    [self setBarButtons:rightBarButtons withButtonWidth:size.width withButtonHeight:size.height inView:rightBtnView];
}

- (void) setBarButtons:(NSArray *)barButtons withButtonWidth:(CGFloat)width withButtonHeight:(CGFloat)height inView:(UIView *) container {
    
    // Remove All Previous Icons
    [container.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj removeFromSuperview];
    }];
    
    // Set View Width.
    __block CGFloat containerViewWidth = barButtons.count * width;
    CGRect containerViewRect = container.frame;
    if ([container isEqual:leftBtnView])
        //gamex
        //containerViewRect.origin.x = kPadding - 5.0;
        containerViewRect.origin.x =  5.0;
    else
        containerViewRect.origin.x = SCREEN_WIDTH()-containerViewWidth;
    containerViewRect.size.width = containerViewWidth;
    [container setFrame:containerViewRect];
    
    // Add Buttons In Top Bar
    [barButtons enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        CGRect rect = obj.frame;
        rect.origin.y = 0;
        rect.size.height = height;
        rect.origin.x = width*idx;
        rect.size.width = width;
        [obj setFrame:rect];
        [obj setTag:idx+1];
        [obj setCenter:CGPointMake(obj.center.x, container.height/2)];
        [obj setBackgroundColor:[UIColor clearColor]];
        [container addSubview:obj];
    }];
    
    // Set Title Alignment
    [self setTitleAlignment:5];
}

- (void) setTitleAlignment:(NSInteger)margin {
    CGRect titleRect = _lblTitle.frame;
    CGFloat titleX =  leftBtnView.frame.size.width;
    CGFloat titleWidth =  SCREEN_WIDTH() - (leftBtnView.frame.size.width + rightBtnView.frame.size.width + margin);
    /*if (leftBtnView.frame.size.width > rightBtnView.frame.size.width) {
        titleWidth = SCREEN_WIDTH() - (leftBtnView.frame.size.width+margin)*2;
    } else {
        titleWidth = SCREEN_WIDTH() - (rightBtnView.frame.size.width+margin)*2;
    }*/
    titleRect.origin.x = titleX;
    titleRect.size.width = titleWidth;
    [_lblTitle setFrame:titleRect];
    [_lblTitle setBackgroundColor:[UIColor clearColor]];
    //[_lblTitle setCenter:CGPointMake(SCREEN_WIDTH()/2, _lblTitle.center.y)];
    
    //[self setUserDetailWidth];
}

#pragma mark - Search Methods.

- (void) showSearchBar:(NSString *)searchText didTextChangeBlock:(TopSearchTextChangeBlock) textChangeBlock didPressSearchBlock:(TopSearchPressSearchBlock) pressSearchBlock didPressCancelSearchBlock:(TopSearchCancelSearchBlock) cancelSearchBlock {
    
    // Set Block
    _searchTextDidChange = textChangeBlock;
    _pressSearchButton = pressSearchBlock;
    _pressCancelButton = cancelSearchBlock;
    
    [searchView setHidden:NO];
    [searchBar setText:searchText];
    [searchBar becomeFirstResponder];
    
    _isSearchEnable = YES;
}

- (void) hideSearchBar {
    [searchView setHidden:YES];
    [searchBar resignFirstResponder];
    _isSearchEnable = NO;
    searchBar.text = @"";
}

- (NSString *) searchText {
    if (_isSearchEnable) {
        return searchBar.text.getValidString;
    }
    return @"";
}

- (BOOL)searchBar:(UISearchBar *)searchBarObj shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    NSString *searchText = [searchBarObj.text stringByReplacingCharactersInRange:range withString:text];
    if (_searchTextDidChange) {
        _searchTextDidChange(searchText);
    }
    return YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBarObj {
    [searchBarObj resignFirstResponder];
    if (_pressSearchButton) {
        _pressSearchButton(searchBarObj.text);
    }
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBarObj {
    [searchView setHidden:YES];
    [searchBarObj resignFirstResponder];
    _isSearchEnable = NO;
    if (_pressCancelButton) {
        _pressCancelButton();
    }
}

#pragma mark - User Details

- (void) showUserDetails:(id)contacts {
    [_lblTitle setHidden:YES];
    [_userDetails setHidden:NO];
    
    // Set Profile image Corner.
    [_viewProfile setCornerRadius:_viewProfile.width/2];
    [_viewProfile.layer setBorderColor:[[UIColor lightGrayColor]colorWithAlphaComponent:.3].CGColor];
    [_viewProfile.layer setBorderWidth:1];
    

    [_lblTitle setHidden:NO];
    [_userDetails setHidden:YES];
}

- (void) setUserDetailWidth {
//    CGFloat width = [_lblUserTitle.text sizeForMaxWidth:_lblTitle.width withFont:_lblUserTitle.font].width;
    CGRect oldBounds = _lblUserTitle.frame;
    [_lblUserTitle sizeToFit];
    CGRect newBounds = _lblUserTitle.frame;
    newBounds.size.height = oldBounds.size.height;
    _lblUserTitle.frame = newBounds;
    [_userDetails setWidth:_lblUserTitle.width];
//    [_userDetails setCenterX:_lblTitle.center.x];
    //[_userDetails setCenterX:(SCREEN_WIDTH()/2)-10];
    
}

- (void) hideUserDetails {
    [_userDetails setHidden:YES];
    [_lblTitle setHidden:NO];
}

//- (void)setContactImage:(id) contact {
//    NSString *strURL;
//    if ([contact isKindOfClass:[Contacts class]]) {
//        strURL = ((Contacts *)contact).imageUrl;
//    }
//    if ([strURL getValidString].length > 0) {
//        if (![strURL isBeginsWith:@"http://"] &&
//            ![strURL isBeginsWith:@"https://"]) {
//            NSString *filePath = [NSString stringWithFormat:@"%@/%@",kDocumentFolderPath, strURL];
//            _imgViewUser.image = [[UIImage alloc] initWithContentsOfFile:filePath];
//        } else {
//            [_imgViewUser setImageWithURL:strURL usingActivityIndicatorViewStyle:UIActivityIndicatorViewStyleGray];
//        }
//        _lblUserLetterImage.hidden = YES;
//    }
//    else {
//        _imgViewUser.image = nil;
//        _lblUserLetterImage.hidden = NO;
//        NSString *contactName;
//        if ([contact isKindOfClass:[Contacts class]]) {
//            contactName = ((Contacts *)contact).contactName;
//        } 
//        if (contactName.length > 1) {
//            NSString *firstCharacters = [contactName substringWithRange:NSMakeRange(0, 1)];
//            _lblUserLetterImage.text = [firstCharacters uppercaseString];
//        }
//    }
//}

#pragma mark - Get buttons

- (UIButton *)leftButtonAtIndex:(NSInteger)index {
    id button = [leftBtnView viewWithTag:index];
    if ([button isKindOfClass:[UIButton class]]) {
        return button;
    }
    return nil;
}

- (UIButton *)rightButtonAtIndex:(NSInteger)index {
    id button = [rightBtnView viewWithTag:index];
    if ([button isKindOfClass:[UIButton class]]) {
        return button;
    }
    return nil;
}

@end

@implementation NSMutableArray (NavBarButtons)

- (void)addBarButtonWithTintColor:(UIColor *)color icon:(UIImage *)icon target:(id)tagret selector:(SEL) selector forControlEvents:(UIControlEvents)event {
    [self addBarButtonWithTintColor:color icon:icon target:tagret selector:selector forControlEvents:event withNotification:NO];
}

- (void)addBarButtonWithTintColor:(UIColor *)color title:(NSString *)title target:(id)tagret selector:(SEL) selector forControlEvents:(UIControlEvents)event {
    [self addBarButtonWithTintColor:color title:title icon:nil target:tagret selector:selector forControlEvents:event withNotification:NO];
}

- (void)addBarButtonWithTintColor:(UIColor *)color icon:(UIImage *)icon target:(id)tagret selector:(SEL) selector forControlEvents:(UIControlEvents)event withNotification:(BOOL)addNotification
{
    [self addBarButtonWithTintColor:color title:@"" icon:icon target:tagret selector:selector forControlEvents:event withNotification:addNotification];
}

- (void)addBarButtonWithTintColor:(UIColor *)color :(NSString *)title icon:(UIImage *)icon target:(id)tagret selector:(SEL) selector forControlEvents:(UIControlEvents)event withNotification:(BOOL)addNotification
{
    [self addBarButtonWithTintColor:color title:title icon:icon target:tagret selector:selector forControlEvents:event withNotification:addNotification];
}



- (void)addBarButtonWithTintColor:(UIColor *)color title:(NSString *)title icon:(UIImage *)icon target:(id)tagret selector:(SEL) selector forControlEvents:(UIControlEvents)event withNotification:(BOOL)addNotification
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.backgroundColor = [UIColor clearColor];
    [button setImage:icon forState:UIControlStateNormal];
    [button setTitleColor:color forState:UIControlStateNormal];
    [button setTitle:title forState:UIControlStateNormal];
    [button.imageView setContentMode:UIViewContentModeScaleAspectFit];
    [button setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
    [button removeTarget:tagret action:NULL forControlEvents:event];
    [button addTarget:tagret action:selector forControlEvents:event];
    [self addObject:button];
    
    if (addNotification) {
        CGFloat xDisplacement = button.frame.size.width-(kNotificationDefaultHeight+2);
        UILabel * notificationLabel = [[UILabel alloc] initWithFrame:CGRectMake(xDisplacement, 5, kNotificationDefaultHeight, kNotificationDefaultHeight)];
        [notificationLabel setAutoresizingMask:UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin];
        [notificationLabel setTextAlignment:NSTextAlignmentCenter];
        [notificationLabel setFont:[UIFont systemFontOfSize:kNotificationFontSize]];
        [notificationLabel setBackgroundColor:[UIColor flatRedColor]];
        [notificationLabel setTextColor:[UIColor whiteColor]];
        [notificationLabel.layer setCornerRadius:kNotificationDefaultHeight/2];
        [notificationLabel setClipsToBounds:YES];
        [notificationLabel setHidden:YES];
        [notificationLabel setTag:kNotificationLabelTag];
        [button addSubview:notificationLabel];
    }
}

- (void)addBarButtonForTodayDateWithTintColor:(UIColor *)color icon:(UIImage *)icon target:(id)tagret selector:(SEL) selector forControlEvents:(UIControlEvents)event
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.backgroundColor = [UIColor clearColor];
    [button setImage:icon forState:UIControlStateNormal];
    [button setTitleColor:color forState:UIControlStateNormal];
    [button.imageView setContentMode:UIViewContentModeScaleAspectFit];
    [button setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
    [button removeTarget:tagret action:NULL forControlEvents:event];
    [button addTarget:tagret action:selector forControlEvents:event];
    [self addObject:button];
    
    UILabel * todayLabel = [[UILabel alloc] initWithFrame:CGRectMake(7, 18, kTodayLabelDefaultWidth, kTodayLabelDefaultHeight)];
    [todayLabel setTextAlignment:NSTextAlignmentCenter];
    [todayLabel setFont:[UIFont systemFontOfSize:kTodayLabelFontSize]];
    [todayLabel setBackgroundColor:[UIColor clearColor]];
    [todayLabel setTextColor:[UIColor whiteColor]];
    [todayLabel setClipsToBounds:YES];
    [todayLabel setTag:kTodayLabelTag];
    [button addSubview:todayLabel];
}

@end


@implementation NSArray (NavBarButtons)

- (BOOL)sw_isEqualToButtons:(NSArray *)buttons
{
    buttons = [buttons copy];
    if (!buttons || self.count != buttons.count) return NO;
    
    for (NSUInteger idx = 0; idx < self.count; idx++) {
        id buttonA = self[idx];
        id buttonB = buttons[idx];
        if (![buttonA isKindOfClass:[UIButton class]] || ![buttonB isKindOfClass:[UIButton class]]) return NO;
        if (![[self class] sw_button:buttonA isEqualToButton:buttonB]) return NO;
    }
    
    return YES;
}

+ (BOOL)sw_button:(UIButton *)buttonA isEqualToButton:(UIButton *)buttonB
{
    if (!buttonA || !buttonB) return NO;
    
    UIColor *backgroundColorA = buttonA.backgroundColor;
    UIColor *backgroundColorB = buttonB.backgroundColor;
    BOOL haveEqualBackgroundColors = (!backgroundColorA && !backgroundColorB) || [backgroundColorA isEqual:backgroundColorB];
    
    NSString *titleA = [buttonA titleForState:UIControlStateNormal];
    NSString *titleB = [buttonB titleForState:UIControlStateNormal];
    BOOL haveEqualTitles = (!titleA && !titleB) || [titleA isEqualToString:titleB];
    
    UIImage *normalIconA = [buttonA imageForState:UIControlStateNormal];
    UIImage *normalIconB = [buttonB imageForState:UIControlStateNormal];
    BOOL haveEqualNormalIcons = (!normalIconA && !normalIconB) || [normalIconA isEqual:normalIconB];
    
    UIImage *selectedIconA = [buttonA imageForState:UIControlStateSelected];
    UIImage *selectedIconB = [buttonB imageForState:UIControlStateSelected];
    BOOL haveEqualSelectedIcons = (!selectedIconA && !selectedIconB) || [selectedIconA isEqual:selectedIconB];
    
    return haveEqualBackgroundColors && haveEqualTitles && haveEqualNormalIcons && haveEqualSelectedIcons;
}

@end


@implementation UIButton (TopBarNotification)

- (void) setNavBarItemImage:(UIImage *)image {
    if (self) {
        [self setImage:image forState:UIControlStateNormal];
    }
}

- (void) setNotificationBadge:(NSInteger)count {
    if ([self viewWithTag:kNotificationLabelTag]) {
        id label = [self viewWithTag:kNotificationLabelTag];
        if (count > 0) {
            [label setHidden:NO];
            if ([label isKindOfClass:[UILabel class]]) {
                ((UILabel*)label).text = [NSString stringWithFormat:@"%ld",(long)count];
                [((UILabel*)label) sizeToFit];
                CGRect rect = ((UILabel*)label).frame;
                if (rect.size.width < kNotificationDefaultHeight)
                    rect.size.width = kNotificationDefaultHeight;
                else
                    rect.size.width = rect.size.width + 5;
                rect.size.height = kNotificationDefaultHeight;
                rect.origin.x = self.frame.size.width-(rect.size.width+2);;
                [(UILabel*)label setFrame:rect];
            }
        } else {
            [label setHidden:YES];
        }
    }
}

- (void) setTodayDate:(NSString *) strDate {
    if ([self viewWithTag:kTodayLabelTag]) {
        id label = [self viewWithTag:kTodayLabelTag];
        if (label) {
            [label setHidden:NO];
            if ([label isKindOfClass:[UILabel class]]) {
                ((UILabel*)label).text = strDate;
            }
        }
    }
}

@end
