

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

#define kUtility [Utility sharedUtility]


static void (^KeyboardWillShowNotificationBlock)(CGSize size);
static void (^KeyboardWillHideNotificationBlock)(CGSize size);
@interface Utility : NSObject

+ (Utility *)sharedUtility;

+ (void)convertSecondIntoWDHMS:(NSInteger)totalSeconds WithBlock:(void (^)(NSInteger week, NSInteger day, NSInteger hours, NSInteger minutes, NSInteger seconds))completion;
+ (void)convertSecondIntoHMS:(NSTimeInterval)timestamp WithBlock:(void (^)(NSInteger hours, NSInteger minutes, NSInteger seconds))completion;

- (NSDate *)dateFromUnixTimeStamp:(NSTimeInterval)unixTime timeZone:(NSTimeZone *)timeZone;

- (void)keyboardWillShowWithCompletion:(void (^)(CGSize size))completion;
- (void)keyboardWillHideWithCompletion:(void (^)(CGSize size))completion;
- (NSString *)addressStringFromPlacemark:(CLPlacemark *)placemark;

@end
