//
//  CommonVaribles.m
//  CommonClassesDemo
//
//  Created on 13/08/15.
//
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "CommonVaribles.h"


CGFloat SCREEN_WIDTH() {
    return ([UIScreen mainScreen].bounds.size.width);
}

CGFloat SCREEN_HEIGHT() {
    return ([UIScreen mainScreen].bounds.size.height);
}

id APP_DELEGATE() {
    return [[UIApplication sharedApplication] delegate];
}

NSString * DEVICE_ID() {
    return [[[UIDevice currentDevice] identifierForVendor] UUIDString];
}

CGFloat IOS_VERSION() {
    return [[[UIDevice currentDevice] systemVersion] floatValue];
}

#pragma mark - Other

id CURRENT_LANGUAGE() {
    return [[NSLocale preferredLanguages] objectAtIndex:0];
}

CGFloat DEVICE_DEPEND_VALUE(CGFloat iPhone4, CGFloat iPhone5, CGFloat iPhone6, CGFloat iPhone6Plus, CGFloat iPad) {
    return IS_IPHONE_4() ? iPhone4: (IS_IPHONE_5() ? iPhone5: (IS_IPHONE_6() ? iPhone6 : (IS_IPHONE_6_PLUS()? iPhone6Plus : iPad)));
}

CGFloat KEYBOARD_HEIGHT() {
    return DEVICE_DEPEND_VALUE(216, 216, 258, 271, 264);
}

#pragma mark -  ----------------------Device Type----------------------


BOOL IS_IPHONE_4() {
    return (fabs((double)[[UIScreen mainScreen] bounds].size.height - (double)480) < DBL_EPSILON);
}

BOOL IS_IPHONE_5() {
    return (fabs((double)[[UIScreen mainScreen] bounds].size.height - (double)568) < DBL_EPSILON);
}

BOOL IS_IPHONE_6() {
    return (fabs((double)[[UIScreen mainScreen] bounds].size.height - (double)667) < DBL_EPSILON);
}

BOOL IS_IPHONE_6_PLUS() {
    return (fabs((double)[[UIScreen mainScreen] bounds].size.height - (double)736) < DBL_EPSILON);
}

BOOL IS_IPAD() {
    return (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad);
}

#pragma mark -  ----------------------Check system version----------------------


BOOL SYSTEM_VERSION_EQUAL_TO(NSString *version) {
    return ([[[UIDevice currentDevice] systemVersion] compare:version options:NSNumericSearch] == NSOrderedSame);
}

BOOL SYSTEM_VERSION_GREATER_THAN(NSString *version) {
    return ([[[UIDevice currentDevice] systemVersion] compare:version options:NSNumericSearch] == NSOrderedDescending);
}

BOOL SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(NSString *version) {
    return ([[[UIDevice currentDevice] systemVersion] compare:version options:NSNumericSearch] != NSOrderedAscending);
}

BOOL SYSTEM_VERSION_LESS_THAN(NSString *version) {
    return ([[[UIDevice currentDevice] systemVersion] compare:version options:NSNumericSearch] == NSOrderedAscending);
}

BOOL SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(NSString *version) {
    return ([[[UIDevice currentDevice] systemVersion] compare:version options:NSNumericSearch] != NSOrderedDescending);
}

#pragma mark -  ----------------------Image----------------------

UIImage * RESIZABLE_IMAGE(NSString *name, CGFloat top, CGFloat left, CGFloat bottom, CGFloat right) {
    return [[UIImage imageNamed:name] resizableImageWithCapInsets:UIEdgeInsetsMake(top,left,bottom,right)];
}

UIImage * RESIZABLE_IMAGE_WITH_MODE(NSString *name, CGFloat top, CGFloat left, CGFloat bottom, CGFloat right, UIImageResizingMode mode) {
    return [[UIImage imageNamed:name] resizableImageWithCapInsets:UIEdgeInsetsMake(top,left,bottom,right) resizingMode:mode];
}

#pragma mark -  ----------------------Color----------------------

UIColor * RGBACOLOR(CGFloat red, CGFloat green, CGFloat blue, CGFloat alpha) {
    return [UIColor colorWithRed:(red)/255.0f green:(green)/255.0f blue:(blue)/255.0f alpha:alpha];
}

UIColor * RGBCOLOR(CGFloat red, CGFloat green, CGFloat blue) {
    return RGBACOLOR(red, green, blue, 1);
}

UIColor * UICOLOR_FROM_RGB_VALUE(int rgbValue) {
    return [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0
                           green:((float)((rgbValue & 0xFF00) >> 8))/255.0
                            blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0];
}

#pragma mark -  ----------------------Math----------------------

NSInteger RANDOM_NUMBER(NSInteger min, NSInteger max) {
    return ((min) + arc4random()%((max)-(min)+1));
}

CGFloat DEGEREE_TO_RADIAN(CGFloat degree) {
    return (M_PI * (degree) / 180.0);
}

CGFloat RADIAN_TO_DEGREE(CGFloat radian) {
    return (radian*180.0)/(M_PI);
}

#pragma mark -  ----------------------Call----------------------

BOOL CAN_TEL() {
    return [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tel:"]];
}

void TEL(NSString *phoneNumber) {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"telprompt:%@",phoneNumber]]];
}

#pragma mark -  ----------------------URL----------------------

BOOL CAN_OPEN_URL(NSString *urlSchema) {
    return [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:urlSchema]];
}

void OPEN_URL(NSString *urlSchema) {
    ([[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlSchema]]);
}

#pragma mark -  ----------------------Read the text file , the default encoding is UTF-8----------------------

NSString * FILE_STRING(NSString *name, NSString *extention) {
    return [[NSString alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:(name) ofType:(extention)] encoding:NSUTF8StringEncoding error:nil];
}

NSDictionary * FILE_DICTIONARY(NSString *name, NSString *extention) {
    return [[NSDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:(name) ofType:(extention)]];
}

NSArray * FILE_ARRAY(NSString *name, NSString *extention) {
    return [[NSArray alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:(name) ofType:(extention)]];
}

#pragma mark -  ----------------------System  Clipboard----------------------

void PASTE_STRING(NSString *string) {
    [[UIPasteboard generalPasteboard] setString:string];
}

void PASTE_IMAGE(UIImage *image) {
    [[UIPasteboard generalPasteboard] setImage:image];
}

#pragma mark - ----------------------Notifications----------------------

void NOTIFICATION_ADD(id anObserver, SEL aSEL, NSString *noteName, id anObj) {
    [[NSNotificationCenter defaultCenter] addObserver:anObserver selector:aSEL name:noteName object:anObj];
}

void NOTIFICATION_REMOVE(id anObserver, NSString *noteName, id anObj) {
    [[NSNotificationCenter defaultCenter] removeObserver:anObserver name:noteName object:anObj];
}

void NOTIFICATION_POST(NSString *notifName, id anObj, NSDictionary *anUserInfo) {
    [[NSNotificationCenter defaultCenter] postNotificationName:notifName object:anObj userInfo:anUserInfo];
}

void NOTIFICATION_REMOVE_OBSERVER(id anObserver) {
    [[NSNotificationCenter defaultCenter] removeObserver:(anObserver)];
}

@implementation CommonVaribles

@end
