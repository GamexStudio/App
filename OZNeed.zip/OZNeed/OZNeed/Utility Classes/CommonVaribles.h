//
//  CommonVaribles.h
//  CommonClassesDemo
//
//  Created on 13/08/15.
//
//

#import <Foundation/Foundation.h>

CGFloat SCREEN_WIDTH();
CGFloat SCREEN_HEIGHT();
id APP_DELEGATE();

NSString * DEVICE_ID();
CGFloat IOS_VERSION();

#pragma mark -

id CURRENT_LANGUAGE();
CGFloat DEVICE_DEPEND_VALUE(CGFloat iPhone4, CGFloat iPhone5, CGFloat iPhone6, CGFloat iPhone6Plus, CGFloat iPad);
CGFloat KEYBOARD_HEIGHT();

#pragma mark -

BOOL IS_IPHONE_4();
BOOL IS_IPHONE_5();
BOOL IS_IPHONE_6();
BOOL IS_IPHONE_6_PLUS();
BOOL IS_IPAD();

#pragma mark -

BOOL SYSTEM_VERSION_EQUAL_TO(NSString *version);
BOOL SYSTEM_VERSION_GREATER_THAN(NSString *version);
BOOL SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(NSString *version);
BOOL SYSTEM_VERSION_LESS_THAN(NSString *version);
BOOL SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(NSString *version);

#pragma mark -

UIImage * RESIZABLE_IMAGE(NSString *name, CGFloat top, CGFloat left, CGFloat bottom, CGFloat right);
UIImage * RESIZABLE_IMAGE_WITH_MODE(NSString *name, CGFloat top, CGFloat left, CGFloat bottom, CGFloat right, UIImageResizingMode mode);

#pragma mark -

UIColor * RGBACOLOR(CGFloat red, CGFloat green, CGFloat blue, CGFloat alpha);
UIColor * RGBCOLOR(CGFloat red, CGFloat green, CGFloat blue);
UIColor * UICOLOR_FROM_RGB_VALUE(int rgbValue);

#pragma mark -

NSInteger RANDOM_NUMBER(NSInteger min, NSInteger max);
CGFloat DEGEREE_TO_RADIAN(CGFloat degree);
CGFloat RADIAN_TO_DEGREE(CGFloat radian);

#pragma mark -

BOOL CAN_TEL();
void TEL(NSString *phoneNumber);

#pragma mark - 

BOOL CAN_OPEN_URL(NSString *urlSchema);
void OPEN_URL(NSString *urlSchema);

#pragma mark - 

NSString * FILE_STRING(NSString *name, NSString *extention);
NSDictionary * FILE_DICTIONARY(NSString *name, NSString *extention);
NSArray * FILE_ARRAY(NSString *name, NSString *extention);

#pragma mark -

void PASTE_STRING(NSString *string);
void PASTE_IMAGE(UIImage *image);

#pragma mark -

void NOTIFICATION_ADD(id anObserver, SEL aSEL, NSString *noteName, id anObj);
void NOTIFICATION_REMOVE(id anObserver, NSString *noteName, id anObj);
void NOTIFICATION_POST(NSString *notifName, id anObj, NSDictionary *anUserInfo);
void NOTIFICATION_REMOVE_OBSERVER(id anObserver);

@interface CommonVaribles : NSObject


@end
