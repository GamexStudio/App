//
//  UIFlatTextField.h
//  Test
//
//  Created by   on 01/02/17.
//  Copyright © 2017 Nishita_MAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIFlatTextField : UITextField
@property (nonatomic) UIColor *seperatorColor;
@property (nonatomic) UIColor *placeHolderColor;
@property (nonatomic) UIColor *clearButtonColor;

@end
