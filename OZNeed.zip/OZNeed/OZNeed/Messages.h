//
//  Messages.h
//  
//
//  Created on 17/11/15.
//
//

#ifndef Messages_h
#define Messages_h

#define kLoginMessage                       @"You have Logged in successfully"
#define kLogoutMessage                      @"You have logged out successfully"
#define kRegistrationMessage                @"You have registered successfully"

#define kEnterStreetMessage                 @"Please enter street name"
#define kEnterTitleMessage                  @"Please enter title"
#define kEnterDescriptionMessage            @"Please enter description"
#define kEnterImageMessage                  @"Please select image"
#define kEnterOldPasswordMessage            @"Please enter old password"
#define kEnterNewPasswordMessage            @"Please enter new password"

#define kEnterUsernameMessage               @"Please enter username"
#define kEnterNameMessage                   @"Please enter full name"
#define kEnterbirthDateMessage              @"Please enter birthdate"
#define kEnterAgeMessage                    @"Please enter age"

#define kEnterCountryMessage                @"Please select country"
#define kEnterEmailMessage           @"Please enter email address"

#define kEnterEmailAddressMessage           @"Please enter phone number/email address"
#define kEnterValidEmailAddressMessage      @"Please enter valid email address"
#define kEnterMobileMessage                 @"Please enter mobile number"
#define kEnterMobileNumber10DigitMessage    @"Please enter 10 digit mobile number"
#define kEnterPasswordMessage               @"Please enter Password"

#define kEnterExistingPassword              @"Please enter existing password"

#define kEnterConfirmPasswordMessage        @"Please enter confirm password"
#define kPasswordAndConfirmPasswordNotMatchedMessage    @"Password and confirm password doesn't match"

#define kEnterRequireFieldMessage           @"Please insert required fields"
#define kProfileSuccessMessage              @"Profile updated successfully"

#define kAcceptLicenceAgreement             @"Please agree to terms and conditions"
#define kConfirmLogoutMessage               @"Are you sure want to logout?"


#define kPasswordMinimumMessage             @"Password should be at least 6 characters long"
#define kNewPasswordMinimumMessage          @"New password should be at least 6 characters long"

#define KCountryMessage                     @"Please select country"
#define KStateMessage                       @"Please select state"
#define KsuburbMessage                      @"Please select suburb"
#define Kaddress                            @"Please enter address"
#define KDescriptionMessage                 @"Please enter Description"

#define KSOSContactMessage                   @"Please select contact"
#define KCommentMessage                     @"Please enter comments"

#define kCategoryListFailMessage            @"Unable to get category list please go back and come again"

#define kSelectExpireDateMessage            @"Please select wish expiry date"
#define kSelectExpireTimeMessage            @"Please select wish expiry time"


#define kSuceess                            @"Success"
#define kError                              @"Error"
#define kSelectcategoryMessage            @"Please select category"
#define kSelectstateMessage               @"Please select state"
#define KgroupNameMessage                 @"Please enter group name"


#endif /* Messages_h */
