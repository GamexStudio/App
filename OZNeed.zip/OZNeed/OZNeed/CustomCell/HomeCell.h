//
//  HomeCell.h
//  OZNeed
//
//  Created by   on 24/07/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgService;
@property (weak, nonatomic) IBOutlet UILabel *lblServiceName;
@end
