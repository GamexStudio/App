//
//  Constant.h
//  OZNeed
//
//  Created by   on 26/02/17.
//  Copyright © 2017 Gamex. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CommonHeaders.h"
@interface Constant : NSObject

#define kListCellIdentifiers  @"ListCell"


#define BASE_URL @"http://rudracrm.com/ozmarket/"
extern NSString* const URL_LOGIN;
extern NSString* const URL_REGISTER;



//Custom Color Method

+ (UIColor *)defaultBorderColor;
+(UIColor *)defaultRedColor;

+ (void)setBackgroundGradient:(UIView *)mainView color1Red:(float)colorR1 color1Green:(float)colorG1 color1Blue:(float)colorB1 color2Red:(float)colorR2 color2Green:(float)colorG2 color2Blue:(float)colorB2 alpha:(float)alpha;
@end
